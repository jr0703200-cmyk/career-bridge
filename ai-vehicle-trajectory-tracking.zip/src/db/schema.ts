import { pgTable, serial, integer, boolean, text, timestamp, real, index } from "drizzle-orm/pg-core";

export const cameras = pgTable("cameras", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  area: text("area").notNull(),
  direction: text("direction").notNull(),
  lat: real("lat").notNull(),
  lng: real("lng").notNull(),
  online: boolean("online").notNull().default(true),
});

export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  plate: text("plate").notNull().unique(),
  kind: text("kind").notNull(), // car | two_wheeler | bus | truck
  color: text("color").notNull(),
  region: text("region").notNull(), // e.g. UP16, KA01
  wanted: boolean("wanted").notNull().default(false),
  first_seen: timestamp("first_seen", { withTimezone: true }).notNull(),
  last_seen: timestamp("last_seen", { withTimezone: true }).notNull(),
});

export const detections = pgTable(
  "detections",
  {
    id: serial("id").primaryKey(),
    vehicle_id: integer("vehicle_id").notNull(),
    camera_id: integer("camera_id").notNull(),
    plate: text("plate").notNull(),
    detected_at: timestamp("detected_at", { withTimezone: true }).notNull(),
    confidence: real("confidence").notNull(),
    // transition metrics vs the previous sighting of the same vehicle
    prev_camera_id: integer("prev_camera_id"),
    distance_km: real("distance_km"),
    minutes: real("minutes"),
    speed_kmh: real("speed_kmh"),
    flag: text("flag"), // null | speeding | wanted
  },
  (t) => [
    index("detections_plate_idx").on(t.plate, t.detected_at),
    index("detections_time_idx").on(t.detected_at),
    index("detections_camera_idx").on(t.camera_id),
  ],
);

export type Camera = typeof cameras.$inferSelect;
export type Vehicle = typeof vehicles.$inferSelect;
export type Detection = typeof detections.$inferSelect;
