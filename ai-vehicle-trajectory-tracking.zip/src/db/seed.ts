import { db } from "@/db";
import { cameras, vehicles, detections } from "./schema";
import { haversineKm, normPlate } from "@/lib/geo";
import { and, eq, sql } from "drizzle-orm";

export const CAMERA_SEED = [
  { code: "LW-01", name: "Chowk Gateway", area: "City Centre", direction: "East approach", lat: 26.8529, lng: 80.9422 },
  { code: "LW-02", name: "Hazratganj Circle", area: "City Centre", direction: "Radial", lat: 26.8518, lng: 80.947 },
  { code: "LW-03", name: "Aminabad Junction", area: "North Corridor", direction: "North approach", lat: 26.88, lng: 80.926 },
  { code: "LW-04", name: "Gomti Nagar Flyover", area: "East Corridor", direction: "East approach", lat: 26.869, lng: 81.0035 },
  { code: "LW-05", name: "Alambagh Gate", area: "West Corridor", direction: "West approach", lat: 26.8555, lng: 80.918 },
];

type PlannedEvent = {
  plate: string;
  camera: number; // index into CAMERA_SEED
  at: number; // epoch ms
  conf: number;
};

const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const pick = <T,>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];
const confRoll = () => {
  const r = Math.random();
  return r < 0.72 ? rnd(0.85, 0.99) : rnd(0.62, 0.84);
};

// hour-of-day weights for Indian urban traffic: peaks 8-11 and 17-21
const HOUR_WEIGHTS = [
  1, 1, 1, 1, 1, 2, 3, 6, 9, 8, 7, 6, 5, 5, 5, 5, 6, 8, 9, 8, 6, 4, 3, 2,
];
function weightedHour() {
  const total = HOUR_WEIGHTS.reduce((a, b) => a + b, 0);
  let t = Math.random() * total;
  for (let h = 0; h < 24; h++) {
    t -= HOUR_WEIGHTS[h];
    if (t <= 0) return h;
  }
  return 12;
}

// Epoch ms for IST (dayOffset days ago, hour:minute) — falls back a day if in the future.
function istEpoch(dayOffset: number, hour: number, minute: number): number {
  const offset = 5.5 * 3600 * 1000;
  const t = new Date(Date.now() + offset);
  t.setUTCDate(t.getUTCDate() - Math.floor(dayOffset));
  t.setUTCHours(hour, minute, Math.floor(rnd(0, 59)), 0);
  let real = t.getTime() - offset;
  if (real > Date.now() - 20 * 60000) real -= 24 * 3600 * 1000;
  return real;
}

// Most recent IST hour-of-day h:mm that is not in the future.
function istNowOrYesterday(h: number, m: number): number {
  const offset = 5.5 * 3600 * 1000;
  const now = Date.now();
  const istNow = new Date(now + offset);
  let t = new Date(istNow);
  t.setUTCHours(h, m, Math.floor(rnd(0, 50)), 0);
  let real = t.getTime() - offset;
  if (real > now) real -= 24 * 3600 * 1000;
  return real;
}

const FLEET: Array<{ plate: string; kind: string; color: string }> = [
  { plate: "UP16 AB 1234", kind: "car", color: "White" },
  { plate: "UP16 KJ 7788", kind: "car", color: "Black" }, // wanted
  { plate: "UP16 TX 4421", kind: "car", color: "Silver" }, // speeder
  { plate: "UP14 CQ 2210", kind: "two_wheeler", color: "Red" },
  { plate: "UP15 MP 8354", kind: "car", color: "Grey" },
  { plate: "UP32 KL 9012", kind: "truck", color: "Blue" },
  { plate: "UP19 RD 5567", kind: "two_wheeler", color: "Maroon" },
  { plate: "UP16 GH 3390", kind: "car", color: "Navy" },
  { plate: "KA01 MJ 4321", kind: "car", color: "White" },
  { plate: "KA51 BN 7610", kind: "truck", color: "Green" },
  { plate: "DL01 GK 2277", kind: "bus", color: "Yellow" },
  { plate: "HR08 AC 1194", kind: "car", color: "Grey" },
  { plate: "RJ14 TP 6642", kind: "car", color: "White" },
  { plate: "UP16 SN 7845", kind: "two_wheeler", color: "Black" },
  { plate: "UP15 WV 3920", kind: "car", color: "Red" },
  { plate: "UP32 EZ 8102", kind: "truck", color: "Orange" },
  { plate: "UP16 BQ 1477", kind: "car", color: "White" },
  { plate: "UP19 LM 9931", kind: "two_wheeler", color: "Teal" },
  { plate: "DL03 RS 4456", kind: "car", color: "Black" },
  { plate: "UP16 PT 6208", kind: "bus", color: "Blue" },
];

const TRANSIENTS = [
  "UP16 AZ 1010", "UP16 AZ 1188", "UP14 KK 2044", "UP15 ZZ 3377", "UP32 QQ 4009",
  "UP16 RR 5533", "KA02 HL 6001", "UP16 MV 7042", "DL05 JN 8015", "UP19 BB 9008",
  "UP16 CX 1122", "UP15 YY 2233", "UP32 DD 3344", "UP16 WW 4455", "HR06 FF 5566",
  "UP16 GN 6677", "UP14 QP 7788", "UP16 HK 8899", "RJ15 SD 9900", "UP16 BJ 1234",
  "UP16 KM 2345", "UP16 LQ 3456", "UP15 MT 4567", "UP16 NK 5678", "KA03 PQ 6789",
  "UP16 RV 7890", "UP16 SW 8901", "UP14 TX 9012", "UP16 UY 0123", "UP16 VZ 1468",
];

function buildFleetEvents(): PlannedEvent[] {
  const events: PlannedEvent[] = [];
  const now = Date.now();
  const span = 72 * 3600 * 1000;

  // 1) Brief example: UP16 AB 1234 -> LW-01 @ 10:00, LW-02 @ 10:08, LW-03 @ 10:15
  const t1000 = istNowOrYesterday(10, 0);
  events.push(
    { plate: "UP16 AB 1234", camera: 0, at: t1000, conf: 0.96 },
    { plate: "UP16 AB 1234", camera: 1, at: t1000 + 8 * 60000, conf: 0.93 },
    { plate: "UP16 AB 1234", camera: 2, at: t1000 + 15 * 60000, conf: 0.9 },
  );
  // plus an earlier leg through the west
  events.push({ plate: "UP16 AB 1234", camera: 4, at: t1000 - 22 * 60000, conf: 0.88 });

  // 2) Wanted vehicle: 4 sightings over 48h
  const w1 = istNowOrYesterday(9, 20) - 47 * 3600 * 1000 + rnd(0, 30) * 60000;
  events.push(
    { plate: "UP16 KJ 7788", camera: 2, at: w1, conf: 0.91 },
    { plate: "UP16 KJ 7788", camera: 4, at: w1 + 14 * 60000, conf: 0.87 },
    { plate: "UP16 KJ 7788", camera: 0, at: w1 + 26 * 60000, conf: 0.92 },
    { plate: "UP16 KJ 7788", camera: 1, at: w1 + 41 * 60000, conf: 0.84 },
  );

  // 3) Speeder: LW-03 -> LW-04 in ~4 minutes over ~9.5 km
  const s1 = istNowOrYesterday(18, 40) + rnd(0, 30) * 60000;
  events.push(
    { plate: "UP16 TX 4421", camera: 2, at: s1, conf: 0.89 },
    { plate: "UP16 TX 4421", camera: 3, at: s1 + 4.2 * 60000, conf: 0.86 },
    { plate: "UP16 TX 4421", camera: 3, at: s1 + 19 * 60000, conf: 0.9 },
  );

  // Regular fleet: multi-stop trips over 72h
  for (let i = 3; i < FLEET.length; i++) {
    const v = FLEET[i];
    const n = 3 + Math.floor(Math.random() * 5); // 3-7 stops
    const dayOff = Math.random() < 0.5 ? 0 : Math.random() < 0.7 ? 1 : 2;
    let start = istEpoch(dayOff, weightedHour(), Math.floor(rnd(0, 55)));
    if (start > now - 2 * 3600 * 1000) start -= 24 * 3600 * 1000;
    let cam = Math.floor(Math.random() * 5);
    let t = start;
    for (let e = 0; e < n; e++) {
      if (t > now - 10 * 60000) break;
      if (t < now - span) break;
      events.push({ plate: v.plate, camera: cam, at: t, conf: confRoll() });
      cam = (cam + 1 + Math.floor(Math.random() * 4)) % 5;
      t += rnd(6, 28) * 60000;
      if (Math.random() < 0.18) t += rnd(30, 140) * 60000; // long dwell
    }
  }

  // Synthetic one-shot plates for volume
  const regs = ["UP16", "UP14", "UP15", "UP32", "UP19", "KA01", "DL01", "HR08"];
  const letters = ["AB", "CD", "EF", "GH", "JK", "LM", "NP", "QR", "ST", "UV", "WX", "YZ"];
  const extra = Array.from({ length: 45 }, () =>
    `${pick(regs)} ${pick(letters)} ${String(1000 + Math.floor(Math.random() * 9000))}`,
  );
  for (const p of [...TRANSIENTS, ...extra]) {
    const dayOff = Math.random() < 0.5 ? 0 : Math.random() < 0.65 ? 1 : 2;
    let at = istEpoch(dayOff, weightedHour(), Math.floor(rnd(0, 55)));
    if (at > now - 10 * 60000) at -= 24 * 3600 * 1000;
    events.push({ plate: p, camera: Math.floor(Math.random() * 5), at, conf: confRoll() });
  }

  return events.filter((e) => e.at < now - 60000 && e.at > now - span);
}

type Computed = PlannedEvent & {
  prevCam: number | null;
  distKm: number | null;
  mins: number | null;
  speed: number | null;
};

function computeTransitions(events: PlannedEvent[]): Computed[] {
  const byPlate = new Map<string, PlannedEvent[]>();
  for (const e of events) {
    const list = byPlate.get(e.plate) ?? [];
    list.push(e);
    byPlate.set(e.plate, list);
  }
  const out: Computed[] = [];
  for (const list of byPlate.values()) {
    list.sort((a, b) => a.at - b.at);
    let prev: PlannedEvent | null = null;
    for (const e of list) {
      if (prev && prev.camera !== e.camera) {
        const distKm = haversineKm(CAMERA_SEED[prev.camera], CAMERA_SEED[e.camera]);
        const mins = (e.at - prev.at) / 60000;
        out.push({ ...e, prevCam: prev.camera, distKm, mins, speed: distKm / (mins / 60) });
      } else {
        out.push({ ...e, prevCam: null, distKm: null, mins: null, speed: null });
      }
      prev = e;
    }
  }
  return out.sort((a, b) => a.at - b.at);
}

let liveRecent = new Map<string, number>(); // plate -> last live tick ms

export async function runSeed(clear: boolean) {
  if (clear) {
    await db.delete(detections);
    await db.delete(vehicles);
    await db.delete(cameras);
    await db.execute(
      sql`select setval('detections_id_seq', 1, false),
               setval('vehicles_id_seq', 1, false),
               setval('cameras_id_seq', 1, false)`,
    );
  }
  const camCount = (await db.select().from(cameras)).length;
  if (camCount === 0) {
    await db.insert(cameras).values(CAMERA_SEED.map((c) => ({ ...c, online: true })));
  }
  // real camera ids (survives serial drift after clears)
  const camRows = await db
    .select()
    .from(cameras)
    .orderBy(sql`${cameras.code}`);
  const camIdByIndex = CAMERA_SEED.map((c) => camRows.find((r) => r.code === c.code)?.id);
  const existing = await db.select({ plate: vehicles.plate }).from(vehicles);
  if (existing.length === 0) {
    const all: Computed[] = computeTransitions(buildFleetEvents());
    const plateMap = new Map<string, { kind: string; color: string; first: number; last: number }>();
    for (const e of all) {
      const cur = plateMap.get(e.plate);
      const fleet = FLEET.find((f) => f.plate === e.plate);
      if (cur) {
        cur.first = Math.min(cur.first, e.at);
        cur.last = Math.max(cur.last, e.at);
      } else {
        plateMap.set(e.plate, {
          kind: fleet?.kind ?? "car",
          color: fleet?.color ?? pick(["White", "Grey", "Black", "Red", "Silver"]),
          first: e.at,
          last: e.at,
        });
      }
    }
    const rows = [...plateMap.entries()].map(([plate, m]) => ({
      plate,
      kind: m.kind,
      color: m.color,
      region: normPlate(plate).slice(0, 4),
      wanted: plate === "UP16 KJ 7788",
      first_seen: new Date(m.first),
      last_seen: new Date(m.last),
    }));
    const inserted = await db.insert(vehicles).values(rows).returning();
    const plateToId = new Map(inserted.map((v) => [v.plate, v.id]));

    const detRows = all.map((e) => ({
      vehicle_id: plateToId.get(e.plate)!,
      camera_id: camIdByIndex[e.camera]!,
      plate: e.plate,
      detected_at: new Date(e.at),
      confidence: Math.round(e.conf * 100) / 100,
      prev_camera_id: e.prevCam != null ? camIdByIndex[e.prevCam]! : null,
      distance_km: e.distKm != null ? Math.round(e.distKm * 100) / 100 : null,
      minutes: e.mins != null ? Math.round(e.mins * 10) / 10 : null,
      speed_kmh: e.speed != null ? Math.round(e.speed) : null,
      flag:
        e.plate === "UP16 KJ 7788"
          ? "wanted"
          : e.speed != null && e.speed > 110
            ? "speeding"
            : null,
    }));
    for (let i = 0; i < detRows.length; i += 250) {
      await db.insert(detections).values(detRows.slice(i, i + 250));
    }
  }
  liveRecent = new Map();
}

export async function ensureSeeded() {
  const [{ n }] = await db
    .select({ n: sqlCount() })
    .from(detections);
  if (n === 0) await runSeed(false);
}

function sqlCount() {
  return sql<number>`count(*)`;
}

const SPEED_LIMIT_KMH = 110;

export async function liveTick() {
  const cams = await db.select().from(cameras);
  const vs = await db.select().from(vehicles);
  if (cams.length === 0 || vs.length === 0) return [];

  const now = Date.now();
  const made: Array<{ plate: string; cameraId: number; at: number; conf: number }> = [];
  const nNew = 1 + Math.floor(Math.random() * 2);
  const pool = [...vs].sort(() => Math.random() - 0.5);
  const usedPlates = new Set<string>();

  for (let i = 0; i < nNew; i++) {
    const v = pick(pool);
    if (usedPlates.has(v.plate)) continue;
    usedPlates.add(v.plate);

    // last known camera for this plate (any time), so consecutive cameras differ
    const prevRows = await db
      .select()
      .from(detections)
      .where(eq(detections.plate, v.plate))
      .orderBy(sql`${detections.detected_at} DESC`)
      .limit(1);
    const lastCam = prevRows[0]?.camera_id ?? null;
    const options = cams.filter((c) => c.id !== lastCam);
    const cam = pick(options.length ? options : cams);
    made.push({ plate: v.plate, cameraId: cam.id, at: now + i, conf: confRoll() });
  }

  const out: Array<Record<string, unknown>> = [];
  for (const m of made) {
    const prevRows = await db
      .select()
      .from(detections)
      .where(and(eq(detections.plate, m.plate), sql`${detections.detected_at} < ${new Date(m.at)}`))
      .orderBy(sql`${detections.detected_at} DESC`)
      .limit(1);
    const prevRow = prevRows[0];
    const prevCamRow = prevRow ? cams.find((c) => c.id === prevRow.camera_id) : undefined;
    const thisCamRow = cams.find((c) => c.id === m.cameraId);

    let distKm: number | null = null;
    let mins: number | null = null;
    let speed: number | null = null;
    if (prevRow && prevCamRow && thisCamRow && prevRow.camera_id !== m.cameraId) {
      distKm = haversineKm(prevCamRow, thisCamRow);
      mins = (m.at - prevRow.detected_at.getTime()) / 60000;
      if (mins > 0.05) speed = distKm / (mins / 60);
    }
    const wanted = vs.find((v) => v.plate === m.plate)?.wanted ?? false;
    const flag = wanted ? "wanted" : speed != null && speed > SPEED_LIMIT_KMH ? "speeding" : null;

    const rows = await db
      .insert(detections)
      .values({
        vehicle_id: vs.find((v) => v.plate === m.plate)!.id,
        camera_id: m.cameraId,
        plate: m.plate,
        detected_at: new Date(m.at),
        confidence: Math.round(m.conf * 100) / 100,
        prev_camera_id: prevRow ? prevRow.camera_id : null,
        distance_km: distKm != null ? Math.round(distKm * 100) / 100 : null,
        minutes: mins != null ? Math.round(mins * 10) / 10 : null,
        speed_kmh: speed != null ? Math.round(speed) : null,
        flag,
      })
      .returning();
    await db
      .update(vehicles)
      .set({ last_seen: new Date(m.at) })
      .where(eq(vehicles.plate, m.plate));
    liveRecent.set(m.plate, m.at);
    out.push(rows[0]);
  }
  return out;
}
