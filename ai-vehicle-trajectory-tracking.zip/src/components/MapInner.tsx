"use client";

import { useEffect } from "react";
import { MapContainer, TileLayer, Marker, Polyline, Tooltip, ZoomControl, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { MapViewProps, MapPoint, MapCam } from "./MapView";
import { fmtTime } from "@/lib/geo";

function camIcon(code: string) {
  return L.divIcon({
    className: "",
    html: `<div class="cam-pin">${code.slice(-2)}</div>`,
    iconSize: [30, 30],
    iconAnchor: [15, 15],
  });
}

function dotIcon(seq: number, flag: boolean, dim: boolean) {
  const cls = `traf-dot${flag ? " flag" : ""}${dim ? " dim" : ""}`;
  return L.divIcon({
    className: "",
    html: `<div class="${cls}">${seq}</div>`,
    iconSize: [22, 22],
    iconAnchor: [11, 11],
  });
}

function Fitter({ pts, keyStr }: { pts: { lat: number; lng: number }[]; keyStr: string }) {
  const map = useMap();
  useEffect(() => {
    if (pts.length === 0) return;
    const b = L.latLngBounds(pts.map((p) => [p.lat, p.lng] as [number, number]));
    map.fitBounds(b, { padding: [42, 42], maxZoom: 14 });
  }, [keyStr, map]); // eslint-disable-line react-hooks/exhaustive-deps
  return null;
}

export default function MapInner({
  cams = [],
  points = [],
  activeIndex = null,
  fitKey = "",
  height = "420px",
  showCameras = true,
}: MapViewProps) {
  const limit = activeIndex == null ? points.length : activeIndex + 1;
  const activePts = points.slice(0, limit);
  const allCoords = [
    ...(showCameras ? cams : []).map((c) => ({ lat: c.lat, lng: c.lng })),
    ...points.map((p) => ({ lat: p.lat, lng: p.lng })),
  ];
  const center: [number, number] = allCoords.length
    ? [
        allCoords.reduce((a, p) => a + p.lat, 0) / allCoords.length,
        allCoords.reduce((a, p) => a + p.lng, 0) / allCoords.length,
      ]
    : [26.8529, 80.95];

  const pointTip = (p: MapPoint) => (
    <span className="block min-w-[130px]">
      <span className="font-mono text-[11px] font-bold">{p.label}</span>
      {p.time && <span className="mt-0.5 block text-[10px] opacity-70">{fmtTime(p.time)}</span>}
      {p.speed != null && (
        <span className="mt-0.5 block text-[10px] opacity-70">{Math.round(p.speed)} km/h est.</span>
      )}
    </span>
  );

  return (
    <div style={{ height }} className="relative w-full overflow-hidden rounded-[10px] border border-line">
      <MapContainer center={center} zoom={12} zoomControl={false} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>'
        />
        <ZoomControl position="topright" />

        {showCameras &&
          cams.map((c: MapCam) => (
            <Marker key={`cam-${c.id}`} position={[c.lat, c.lng]} icon={camIcon(c.code)}>
              <Tooltip className="plate-tip" direction="top" offset={[0, -14]}>
                <span className="font-mono text-[11px] font-bold text-sig">{c.code}</span>
                <span className="ml-1.5 text-[10px] opacity-75">{c.name}</span>
              </Tooltip>
            </Marker>
          ))}

        {points.length > 1 && (
          <Polyline
            positions={points.map((p) => [p.lat, p.lng] as [number, number])}
            pathOptions={{ color: "#3ddc97", weight: 3, opacity: 0.18, dashArray: "5 8" }}
          />
        )}
        {activePts.length > 1 && (
          <Polyline
            positions={activePts.map((p) => [p.lat, p.lng] as [number, number])}
            pathOptions={{ color: "#3ddc97", weight: 3.5, opacity: 0.95, className: "traj-anim" }}
          />
        )}

        {points.map((p, i) => (
          <Marker
            key={`pt-${p.id}-${i}`}
            position={[p.lat, p.lng]}
            icon={dotIcon(p.seq, !!p.flag, activeIndex != null && i > activeIndex)}
          >
            <Tooltip className="plate-tip" direction="top" offset={[0, -10]}>
              {pointTip(p)}
            </Tooltip>
          </Marker>
        ))}

        <Fitter pts={allCoords} keyStr={`${fitKey}-${points.length}`} />
      </MapContainer>
    </div>
  );
}
