"use client";

import dynamic from "next/dynamic";

const MapInner = dynamic(() => import("./MapInner"), {
  ssr: false,
  loading: () => (
    <div className="grid h-full w-full place-items-center rounded-[10px] border border-line bg-panel">
      <span className="text-[11px] font-semibold tracking-[0.16em] text-faint uppercase">
        Loading map tiles…
      </span>
    </div>
  ),
});

export type MapPoint = {
  id: number | string;
  lat: number;
  lng: number;
  seq: number;
  label: string;
  time?: string;
  flag?: string | null;
  speed?: number | null;
};

export type MapCam = {
  id: number;
  code: string;
  name: string;
  lat: number;
  lng: number;
  online?: boolean;
};

export type MapViewProps = {
  cams?: MapCam[];
  points?: MapPoint[];
  /** 0-based index into points up to which the route is "travelled"; null/undefined = full route */
  activeIndex?: number | null;
  /** change to force re-fit of bounds */
  fitKey?: string;
  height?: string;
  showCameras?: boolean;
};

export default function MapView(props: MapViewProps) {
  return <MapInner {...props} />;
}
