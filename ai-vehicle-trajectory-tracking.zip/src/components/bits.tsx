import { plateGroups } from "@/lib/geo";
import type { ReactNode } from "react";

export function PlateChip({ plate, size = "md" }: { plate: string; size?: "sm" | "md" | "lg" }) {
  const groups = plateGroups(plate);
  const cls =
    size === "sm"
      ? "px-1.5 py-[1px] text-[10px]"
      : size === "lg"
        ? "px-3 py-1.5 text-sm"
        : "px-2 py-0.5 text-xs";
  return (
    <span className={`plate-chip ${cls}`}>
      {groups.map((g, i) => (
        <span key={i} className="inline-flex items-center gap-1.5">
          {i > 0 && <span className="sep" />}
          {g}
        </span>
      ))}
    </span>
  );
}

export function FlagChip({ flag, wanted }: { flag: string | null; wanted?: boolean }) {
  if (wanted) {
    return (
      <span className="inline-flex items-center gap-1 rounded-[5px] border border-red/50 bg-red/15 px-1.5 py-px text-[10px] font-bold tracking-wide text-red uppercase">
        <svg width="9" height="9" viewBox="0 0 12 12" fill="currentColor">
          <path d="M6 0 7.4 4.6 12 6l-4.6 1.4L6 12 4.6 7.4 0 6l4.6-1.4L6 0Z" />
        </svg>
        Wanted
      </span>
    );
  }
  if (flag === "speeding") {
    return (
      <span className="inline-flex items-center gap-1 rounded-[5px] border border-amb/50 bg-amb/15 px-1.5 py-px text-[10px] font-bold tracking-wide text-amb uppercase">
        Speeding
      </span>
    );
  }
  if (flag === "wanted") {
    return (
      <span className="inline-flex items-center gap-1 rounded-[5px] border border-red/50 bg-red/15 px-1.5 py-px text-[10px] font-bold tracking-wide text-red uppercase">
        Wanted
      </span>
    );
  }
  return (
    <span className="inline-flex items-center rounded-[5px] border border-line2 px-1.5 py-px text-[10px] font-semibold tracking-wide text-mut uppercase">
      Clear
    </span>
  );
}

export function ConfBar({ value }: { value: number }) {
  const pct = Math.round(value * 100);
  const tone = pct >= 85 ? "bg-sig" : pct >= 70 ? "bg-amb" : "bg-red";
  return (
    <span className="inline-flex items-center gap-1.5" title={`ANPR confidence ${pct}%`}>
      <span className="h-1 w-10 overflow-hidden rounded-full bg-line2">
        <span className={`block h-full rounded-full ${tone}`} style={{ width: `${pct}%` }} />
      </span>
      <span className="text-[10px] font-semibold text-mut tabular-nums">{pct}%</span>
    </span>
  );
}

export function StatCard({
  label,
  value,
  sub,
  tone = "default",
}: {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  tone?: "default" | "sig" | "amb" | "red";
}) {
  const valCls =
    tone === "sig" ? "text-sig" : tone === "amb" ? "text-amb" : tone === "red" ? "text-red" : "text-txt";
  return (
    <div className="panel px-4 py-3.5">
      <div className="text-[10.5px] font-bold tracking-[0.14em] text-faint uppercase">{label}</div>
      <div className={`kpi-num mt-1.5 text-[26px] leading-none ${valCls}`}>{value}</div>
      {sub && <div className="mt-1.5 text-[11px] text-mut">{sub}</div>}
    </div>
  );
}

export function SectionTitle({
  title,
  right,
  icon,
}: {
  title: string;
  right?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="mb-3 flex items-center justify-between gap-3">
      <div className="flex items-center gap-2">
        {icon && <span className="text-sig">{icon}</span>}
        <h2 className="font-display text-[13px] font-semibold tracking-[0.08em] text-txt uppercase">
          {title}
        </h2>
      </div>
      {right}
    </div>
  );
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-1.5 py-14 text-center">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#626d80" strokeWidth="1.5">
        <circle cx="12" cy="12" r="9" />
        <path d="M12 8v4l2.5 2.5" />
      </svg>
      <div className="text-sm font-semibold text-mut">{title}</div>
      {hint && <div className="max-w-[300px] text-xs text-faint">{hint}</div>}
    </div>
  );
}

export function LoadingBlock({ label = "Loading" }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2.5 py-14 text-xs font-semibold tracking-wide text-faint uppercase">
      <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-line2 border-t-sig" />
      {label}…
    </div>
  );
}

export function TimeAgo({ iso }: { iso: string }) {
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return `${Math.round(s)}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
}
