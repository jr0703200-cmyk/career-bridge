"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { fmtClock, fmtDay } from "@/lib/geo";

const NAV = [
  {
    href: "/",
    label: "Overview",
    icon: (
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <rect x="3" y="3" width="7.5" height="7.5" rx="1.5" />
        <rect x="13.5" y="3" width="7.5" height="7.5" rx="1.5" />
        <rect x="3" y="13.5" width="7.5" height="7.5" rx="1.5" />
        <rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.5" />
      </svg>
    ),
  },
  {
    href: "/cameras",
    label: "Camera Network",
    icon: (
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <rect x="2.5" y="6.5" width="13" height="11" rx="2" />
        <path d="m15.5 10.5 5.5-3v9l-5.5-3" />
      </svg>
    ),
  },
  {
    href: "/track",
    label: "Vehicle Tracking",
    icon: (
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <circle cx="12" cy="12" r="8.5" />
        <path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3" />
        <circle cx="12" cy="12" r="2.4" fill="currentColor" stroke="none" />
      </svg>
    ),
  },
  {
    href: "/analytics",
    label: "Traffic Analytics",
    icon: (
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
      </svg>
    ),
  },
  {
    href: "/reports",
    label: "Evidence Reports",
    icon: (
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M7 3h8l4 4v14H7z" />
        <path d="M10 12h7M10 16h7M10 8h3" />
      </svg>
    ),
  },
];

function Clock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="hidden items-baseline gap-2 md:flex">
      <span className="kpi-num text-[15px] text-txt tabular-nums">{fmtClock(now)}</span>
      <span className="text-[10px] font-bold tracking-[0.14em] text-faint">
        IST · {fmtDay(now).toUpperCase()}
      </span>
    </div>
  );
}

export default function Shell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [q, setQ] = useState("");
  const [resetting, setResetting] = useState(false);
  const resetRef = useRef(false);

  async function onSearch(e: FormEvent) {
    e.preventDefault();
    const v = q.trim();
    if (!v) return;
    router.push(`/track?plate=${encodeURIComponent(v)}`);
  }

  async function resetData() {
    if (resetRef.current) return;
    resetRef.current = true;
    setResetting(true);
    try {
      await fetch("/api/dev/seed?clear=1", { method: "POST" });
      window.location.href = "/";
    } catch {
      setResetting(false);
      resetRef.current = false;
    }
  }

  return (
    <div className="flex min-h-screen">
      {/* sidebar */}
      <aside className="no-print sticky top-0 flex h-screen w-[218px] shrink-0 flex-col border-r border-line bg-panel">
        <Link href="/" className="flex items-center gap-2.5 border-b border-line px-4 py-4">
          <span className="grid h-8 w-8 place-items-center rounded-[7px] border border-sig/60 bg-sig/10 text-sig">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="8.5" />
              <path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3" />
              <circle cx="12" cy="12" r="2.2" fill="currentColor" stroke="none" />
            </svg>
          </span>
          <span>
            <span className="font-display block text-[15px] leading-none font-bold tracking-tight">
              PlateTrace
            </span>
            <span className="mt-1 block text-[9.5px] font-bold tracking-[0.18em] text-faint uppercase">
              City Vehicle Intel
            </span>
          </span>
        </Link>

        <nav className="flex-1 space-y-0.5 overflow-y-auto px-2.5 py-3">
          {NAV.map((n) => {
            const active = pathname === n.href || (n.href !== "/" && pathname.startsWith(n.href));
            return (
              <Link
                key={n.href}
                href={n.href}
                className={`flex items-center gap-2.5 rounded-[7px] px-2.5 py-2 text-[12.5px] font-semibold transition-colors ${
                  active
                    ? "border border-sig/30 bg-sig/10 text-sig"
                    : "border border-transparent text-mut hover:bg-raise hover:text-txt"
                }`}
              >
                {n.icon}
                {n.label}
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-line px-3 py-3">
          <div className="mb-2 flex items-center gap-2 px-1">
            <span className="dot-live" />
            <span className="text-[10px] font-bold tracking-[0.14em] text-mut uppercase">
              ANPR grid live
            </span>
          </div>
          <button
            onClick={resetData}
            disabled={resetting}
            className="w-full rounded-[7px] border border-line2 px-2.5 py-1.5 text-[11px] font-semibold text-mut transition-colors hover:border-red/50 hover:text-red disabled:opacity-50"
          >
            {resetting ? "Rebuilding dataset…" : "Reset demo dataset"}
          </button>
          <div className="mt-2 px-1 text-[9.5px] leading-relaxed text-faint">
            Lucknow pilot · 5 ANPR nodes
            <br />v0.9 prototype
          </div>
        </div>
      </aside>

      {/* main column */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="no-print sticky top-0 z-40 flex items-center justify-between gap-4 border-b border-line bg-abyss/90 px-5 py-3 backdrop-blur">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-2 rounded-full border border-line2 bg-panel px-3 py-1.5">
              <span className="dot-live" />
              <span className="text-[10.5px] font-bold tracking-[0.16em] text-sig">LIVE</span>
            </span>
            <span className="hidden text-[11.5px] text-faint lg:block">
              Multi-camera ANPR · trajectory reconstruction
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Clock />
            <form onSubmit={onSearch} className="relative">
              <svg
                className="pointer-events-none absolute top-1/2 left-2.5 -translate-y-1/2 text-faint"
                width="13"
                height="13"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <circle cx="11" cy="11" r="7" />
                <path d="m20 20-3.5-3.5" />
              </svg>
              <input
                value={q}
                onChange={(e) => setQ(e.target.value.toUpperCase())}
                placeholder="Search plate · e.g. UP16 AB 1234"
                className="w-[210px] rounded-[7px] border border-line2 bg-panel py-1.5 pr-3 pl-8 font-mono text-[11.5px] tracking-wide text-txt placeholder:font-sans placeholder:tracking-normal placeholder:text-faint focus:border-sig/60 focus:outline-none sm:w-[260px]"
              />
            </form>
          </div>
        </header>
        <main className="app-main mx-auto w-full max-w-[1240px] flex-1 px-5 py-5">{children}</main>
      </div>
    </div>
  );
}
