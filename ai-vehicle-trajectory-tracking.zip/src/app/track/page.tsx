"use client";

import { useCallback, useEffect, useMemo, useRef, useState, Suspense, type FormEvent } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "@/lib/http";
import Shell from "@/components/Shell";
import MapView, { type MapPoint } from "@/components/MapView";
import {
  PlateChip,
  FlagChip,
  ConfBar,
  LoadingBlock,
  EmptyState,
  SectionTitle,
} from "@/components/bits";
import {
  fmtFull,
  fmtKm,
  fmtMinutes,
  fmtSpeed,
  VEHICLE_KINDS,
  normPlate,
} from "@/lib/geo";

type Veh = {
  plate: string;
  kind: string;
  color: string;
  region: string;
  wanted: boolean;
  last_seen: string;
  n: number;
  cams: number;
  flagged: number;
};

type Point = {
  seq: number;
  at: string;
  camCode: string;
  camName: string;
  camArea: string;
  lat: number | null;
  lng: number | null;
  conf: number;
  prevCamCode: string | null;
  distance: number | null;
  minutes: number | null;
  speed: number | null;
  flag: string | null;
};

type Detail = {
  vehicle: Veh;
  path: Point[];
  summary: {
    sightings: number;
    cameras: number;
    totalDistKm: number;
    durationMin: number;
    avgSpeedKmh: number;
    flagged: number;
  };
};

const QUICK = ["UP16 AB 1234", "UP16 KJ 7788", "UP16 TX 4421"];

function TrackInner() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [q, setQ] = useState("");
  const [sugg, setSugg] = useState<Veh[]>([]);
  const [focus, setFocus] = useState(false);
  const [detail, setDetail] = useState<Detail | null>(null);
  const [notFound, setNotFound] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const [idx, setIdx] = useState<number>(0);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);

  const pts: Point[] = detail?.path ?? [];
  const n = pts.length;

  const load = useCallback(
    async (plate: string) => {
      setSelected(plate);
      setLoading(true);
      setNotFound(null);
      if (lastLoaded.current !== plate) {
        lastLoaded.current = plate;
        router.replace(`/track?plate=${encodeURIComponent(plate)}`, { scroll: false });
      }
      try {
        const d = await api<Detail>(`/api/vehicles/${encodeURIComponent(plate)}`);
        setDetail(d);
        setIdx(Math.max(d.path.length - 1, 0));
        setPlaying(false);
      } catch {
        setNotFound(plate);
        setDetail(null);
      } finally {
        setLoading(false);
      }
    },
    [router],
  );

  // selection from URL
  const urlPlate = searchParams.get("plate");
  const lastLoaded = useRef<string | null>(null);
  useEffect(() => {
    if (urlPlate && normPlate(urlPlate) && lastLoaded.current !== urlPlate) {
      load(urlPlate.trim());
    }
  }, [urlPlate, load]);

  // polling for live detections while a vehicle is selected
  useEffect(() => {
    if (!selected) return;
    const t = setInterval(() => load(selected), 8000);
    return () => clearInterval(t);
  }, [selected, load]);

  // suggestions
  useEffect(() => {
    const v = normPlate(q);
    if (!v) {
      setSugg([]);
      return;
    }
    const t = setTimeout(() => {
      api<{ vehicles: Veh[] }>(`/api/vehicles?q=${encodeURIComponent(q.trim())}&limit=8`)
        .then((r) => setSugg(r.vehicles))
        .catch(() => setSugg([]));
    }, 220);
    return () => clearTimeout(t);
  }, [q]);

  // playback
  useEffect(() => {
    if (!playing || n === 0) return;
    const t = setInterval(() => {
      setIdx((i) => Math.min(i + 1, n - 1));
    }, 1300 / speed);
    return () => clearInterval(t);
  }, [playing, speed, n]);

  useEffect(() => {
    if (playing && idx >= n - 1) setPlaying(false);
  }, [idx, n, playing]);

  const mapPoints: MapPoint[] = useMemo(
    () =>
      pts
        .filter((p) => p.lat != null && p.lng != null)
        .map((p) => ({
          id: p.seq,
          lat: p.lat!,
          lng: p.lng!,
          seq: p.seq,
          label: `${p.camCode} · ${p.camName}`,
          time: p.at,
          flag: p.flag,
          speed: p.speed,
        })),
    [pts],
  );

  function onSearch(e: FormEvent) {
    e.preventDefault();
    const p = normPlate(q);
    if (p) load(q.trim());
  }

  const v = detail?.vehicle;

  return (
    <Shell>
      <div className="mb-4">
        <h1 className="font-display text-[22px] font-bold tracking-tight">Vehicle Tracking</h1>
        <p className="mt-0.5 text-[12.5px] text-mut">
          Search a registration to reconstruct its cross-camera route with timestamps and travel times
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-[340px_1fr]">
        {/* left rail */}
        <div className="space-y-4">
          <div className="panel p-3.5">
            <SectionTitle title="Plate Search" />
            <form onSubmit={onSearch} className="relative">
              <input
                value={q}
                onChange={(e) => setQ(e.target.value.toUpperCase())}
                onFocus={() => setFocus(true)}
                onBlur={() => setTimeout(() => setFocus(false), 150)}
                placeholder="UP16 AB 1234"
                className="w-full rounded-[8px] border border-line2 bg-raise px-3 py-2.5 font-mono text-[13px] tracking-wider text-txt placeholder:text-faint focus:border-sig/60 focus:outline-none"
              />
              {focus && sugg.length > 0 && (
                <div className="absolute z-20 mt-1 w-full overflow-hidden rounded-[8px] border border-line2 bg-raise shadow-xl shadow-black/40">
                  {sugg.map((s) => (
                    <button
                      key={s.plate}
                      type="button"
                      onMouseDown={() => {
                        load(s.plate);
                        setQ(s.plate);
                      }}
                      className="flex w-full items-center justify-between gap-2 px-3 py-2 text-left transition-colors hover:bg-panel"
                    >
                      <PlateChip plate={s.plate} size="sm" />
                      <span className="flex items-center gap-1.5">
                        {s.wanted && <FlagChip flag="wanted" />}
                        <span className="text-[10px] text-faint">{s.n} reads</span>
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </form>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {QUICK.map((p) => (
                <button
                  key={p}
                  onClick={() => {
                    setQ(p);
                    load(p);
                  }}
                  className={`rounded-full border px-2.5 py-1 font-mono text-[10.5px] font-bold tracking-wide transition-colors ${
                    selected === p
                      ? "border-sig/60 bg-sig/15 text-sig"
                      : "border-line2 text-mut hover:border-sig/40 hover:text-sig"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
            <div className="mt-2 text-[10px] leading-relaxed text-faint">
              Space and dashes are ignored while matching · try “UP16AB1234”
            </div>
          </div>

          {v && (
            <div className="panel p-3.5">
              <SectionTitle title="Matched Vehicle" />
              <div className="flex items-center justify-between gap-2">
                <PlateChip plate={v.plate} size="lg" />
                {v.wanted ? <FlagChip flag="wanted" /> : <FlagChip flag={detail?.summary.flagged ? "speeding" : null} />}
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-[11.5px]">
                <div className="rounded-[7px] border border-line bg-raise px-2.5 py-2">
                  <div className="text-[9px] font-bold tracking-[0.12em] text-faint uppercase">Class</div>
                  <div className="mt-0.5 font-semibold">{VEHICLE_KINDS[v.kind] ?? v.kind}</div>
                </div>
                <div className="rounded-[7px] border border-line bg-raise px-2.5 py-2">
                  <div className="text-[9px] font-bold tracking-[0.12em] text-faint uppercase">Colour / Region</div>
                  <div className="mt-0.5 font-semibold">
                    {v.color} · {v.region}
                  </div>
                </div>
                <div className="rounded-[7px] border border-line bg-raise px-2.5 py-2">
                  <div className="text-[9px] font-bold tracking-[0.12em] text-faint uppercase">Sightings</div>
                  <div className="kpi-num mt-0.5 text-[15px]">
                    {detail?.summary.sightings} <span className="text-[11px] text-mut">across {detail?.summary.cameras} cams</span>
                  </div>
                </div>
                <div className="rounded-[7px] border border-line bg-raise px-2.5 py-2">
                  <div className="text-[9px] font-bold tracking-[0.12em] text-faint uppercase">Route Span</div>
                  <div className="kpi-num mt-0.5 text-[15px]">
                    {fmtKm(detail?.summary.totalDistKm)}
                  </div>
                </div>
                <div className="rounded-[7px] border border-line bg-raise px-2.5 py-2">
                  <div className="text-[9px] font-bold tracking-[0.12em] text-faint uppercase">On Road</div>
                  <div className="kpi-num mt-0.5 text-[15px]">{fmtMinutes(detail?.summary.durationMin)}</div>
                </div>
                <div className="rounded-[7px] border border-line bg-raise px-2.5 py-2">
                  <div className="text-[9px] font-bold tracking-[0.12em] text-faint uppercase">Avg Speed</div>
                  <div className="kpi-num mt-0.5 text-[15px]">{fmtSpeed(detail?.summary.avgSpeedKmh)}</div>
                </div>
              </div>
              <a
                href={`/reports?plate=${encodeURIComponent(v.plate)}`}
                className="mt-3 flex items-center justify-center gap-2 rounded-[8px] border border-sig/40 bg-sig/10 px-3 py-2 text-[11.5px] font-bold tracking-wide text-sig uppercase transition-colors hover:bg-sig/20"
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M7 3h8l4 4v14H7z" />
                  <path d="M10 12h7M10 16h7" />
                </svg>
                Generate evidence report
              </a>
            </div>
          )}
        </div>

        {/* right: map + playback + timeline */}
        <div className="space-y-4">
          <div className="panel p-3.5">
            <SectionTitle
              title="Trajectory Reconstruction"
              icon={
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="5" cy="19" r="2.5" />
                  <circle cx="19" cy="5" r="2.5" />
                  <path d="M7 17 17 7" />
                </svg>
              }
              right={
                v ? (
                  <span className="text-[11px] text-mut">
                    {v.plate} · {n} matched reads
                  </span>
                ) : undefined
              }
            />

            {loading && <LoadingBlock label="Matching plates across cameras" />}
            {!loading && notFound && (
              <EmptyState
                title={`No matches for ${notFound}`}
                hint="The plate has no ANPR records in the pilot grid. Try one of the quick-search plates above."
              />
            )}
            {!loading && !notFound && !v && (
              <EmptyState
                title="Select a vehicle"
                hint="Search a registration number or pick a quick-search plate to reconstruct its route on the city map."
              />
            )}

            {!loading && v && (
              <>
                <MapView
                  points={mapPoints}
                  activeIndex={idx}
                  fitKey={v.plate}
                  height="400px"
                  showCameras={false}
                />
                {/* playback */}
                <div className="mt-3 flex flex-wrap items-center gap-3 rounded-[8px] border border-line bg-raise px-3 py-2.5">
                  <button
                    onClick={() => {
                      if (idx >= n - 1) setIdx(0);
                      setPlaying((p) => !p);
                    }}
                    disabled={n < 2}
                    className="grid h-8 w-8 place-items-center rounded-full border border-sig/50 bg-sig/15 text-sig transition-colors hover:bg-sig/25 disabled:opacity-40"
                    aria-label={playing ? "Pause" : "Play"}
                  >
                    {playing ? (
                      <svg width="11" height="11" viewBox="0 0 12 12" fill="currentColor">
                        <rect x="1.5" y="1" width="3.2" height="10" rx="1" />
                        <rect x="7.3" y="1" width="3.2" height="10" rx="1" />
                      </svg>
                    ) : (
                      <svg width="11" height="11" viewBox="0 0 12 12" fill="currentColor">
                        <path d="M2.5 1.2 11 6 2.5 10.8Z" />
                      </svg>
                    )}
                  </button>
                  <div className="min-w-[180px] flex-1">
                    <input
                      type="range"
                      min={0}
                      max={Math.max(n - 1, 0)}
                      value={idx}
                      onChange={(e) => {
                        setPlaying(false);
                        setIdx(Number(e.target.value));
                      }}
                      disabled={n < 2}
                      className="w-full accent-[#3ddc97]"
                    />
                  </div>
                  <div className="w-[150px] text-right font-mono text-[10.5px] text-mut tabular-nums">
                    Step {n ? idx + 1 : 0}/{n}
                    {pts[idx] && <span className="ml-1.5 text-txt">{fmtFull(pts[idx].at).split(",").pop()}</span>}
                  </div>
                  <div className="flex gap-1">
                    {[1, 2, 4].map((s) => (
                      <button
                        key={s}
                        onClick={() => setSpeed(s)}
                        className={`rounded-[6px] border px-2 py-1 text-[10.5px] font-bold ${
                          speed === s
                            ? "border-sig/60 bg-sig/15 text-sig"
                            : "border-line2 text-faint hover:text-txt"
                        }`}
                      >
                        {s}×
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* timeline */}
          {!loading && v && (
            <div className="panel p-3.5">
              <SectionTitle
                title="Sighting Timeline"
                right={<span className="text-[10.5px] text-faint">chronological · click to focus</span>}
              />
              <div className="space-y-1">
                {pts.map((p, i) => {
                  const active = i === idx;
                  return (
                    <button
                      key={p.seq}
                      onClick={() => {
                        setPlaying(false);
                        setIdx(i);
                      }}
                      className={`grid w-full grid-cols-[26px_150px_1fr_86px_72px_64px] items-center gap-2 rounded-[7px] border px-2.5 py-2 text-left transition-colors ${
                        active
                          ? "border-sig/50 bg-sig/10"
                          : "border-transparent hover:border-line2 hover:bg-raise"
                      } ${i > idx ? "opacity-45" : ""}`}
                    >
                      <span
                        className={`grid h-6 w-6 place-items-center rounded-full border font-mono text-[10px] font-bold ${
                          p.flag
                            ? "border-red/60 text-red"
                            : active
                              ? "border-sig text-sig"
                              : "border-line2 text-mut"
                        }`}
                      >
                        {p.seq}
                      </span>
                      <span className="font-mono text-[10.5px] leading-tight text-txt tabular-nums">
                        {fmtFull(p.at)}
                      </span>
                      <span className="min-w-0">
                        <span className="block truncate text-[11.5px] font-semibold">
                          <span className="font-mono text-sig">{p.camCode}</span> {p.camName}
                        </span>
                        <span className="block truncate text-[10px] text-faint">
                          {p.prevCamCode ? `via ${p.prevCamCode} · ${fmtKm(p.distance)}` : "first capture"} ·{" "}
                          {p.camArea}
                        </span>
                      </span>
                      <span className="font-mono text-[10.5px] text-mut tabular-nums">{fmtMinutes(p.minutes)}</span>
                      <span
                        className={`font-mono text-[10.5px] font-bold tabular-nums ${
                          p.speed != null && p.speed > 110 ? "text-red" : "text-mut"
                        }`}
                      >
                        {fmtSpeed(p.speed)}
                      </span>
                      <span className="flex items-center justify-end gap-1.5">
                        <ConfBar value={p.conf} />
                        {p.flag && <FlagChip flag={p.flag} />}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </Shell>
  );
}

export default function TrackPage() {
  return (
    <Suspense fallback={<Shell><div className="panel"><LoadingBlock /></div></Shell>}>
      <TrackInner />
    </Suspense>
  );
}
