"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/http";
import Shell from "@/components/Shell";
import { PlateChip, FlagChip, SectionTitle, LoadingBlock, TimeAgo } from "@/components/bits";
import { fmtTime } from "@/lib/geo";
import { BarChart, Bar, XAxis, YAxis, Tooltip, Cell, ResponsiveContainer } from "recharts";

type Analytics = {
  windowHours: number;
  total: number;
  hourly: Array<{ h: number; n: number; load: number }>;
  peak: { hour: number; label: string; load: number; n: number };
  corridors: Array<{ from: string; to: string; n: number; avgMin: number; avgSpeed: number }>;
  regions: Array<{ region: string; n: number; share: number }>;
  camLoad: Array<{ code: string; name: string; n: number; share: number }>;
  alerts: Array<{
    id: number;
    plate: string;
    at: string;
    camCode: string;
    camName: string;
    speed: number | null;
    flag: string | null;
    conf: number;
  }>;
};

const loadColor = (load: number) =>
  load >= 75 ? "#ef5a4c" : load >= 50 ? "#f2b64b" : load >= 25 ? "#7fbf9a" : "#22513c";

export default function AnalyticsPage() {
  const [a, setA] = useState<Analytics | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const refresh = useCallback(() => {
    api<Analytics>("/api/analytics")
      .then(setA)
      .catch((e) => setErr(e.message));
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return (
    <Shell>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-[22px] font-bold tracking-tight">Traffic & Mobility Analytics</h1>
          <p className="mt-0.5 text-[12.5px] text-mut">
            City-wide movement patterns derived from {a ? a.total : "…"} cross-referenced ANPR reads
          </p>
        </div>
        <button
          onClick={refresh}
          className="rounded-[8px] border border-line2 px-3 py-1.5 text-[11px] font-bold tracking-wide text-mut uppercase transition-colors hover:border-sig/40 hover:text-sig"
        >
          Refresh
        </button>
      </div>

      {err && <div className="panel border-red/40 p-4 text-sm text-red">Failed to load analytics: {err}</div>}
      {!a && !err && (
        <div className="panel">
          <LoadingBlock label="Aggregating movements" />
        </div>
      )}

      {a && (
        <div className="space-y-4">
          {/* peak banner */}
          <div className="panel flex flex-wrap items-center gap-x-8 gap-y-3 border-amb/30 bg-amb/[0.06] px-4 py-3.5">
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 place-items-center rounded-[8px] border border-amb/50 bg-amb/15 text-amb">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="9" />
                  <path d="M12 7v5l3.5 2" />
                </svg>
              </span>
              <div>
                <div className="text-[10px] font-bold tracking-[0.16em] text-amb uppercase">Peak congestion window</div>
                <div className="font-display text-[18px] leading-tight font-bold">
                  {a.peak.label} IST <span className="text-[12px] font-semibold text-mut">· grid load {a.peak.load}%</span>
                </div>
              </div>
            </div>
            <div className="text-[11.5px] leading-relaxed text-mut">
              {a.peak.n} plate reads/hour averaged across the 72h window — plan enforcement and signal
              retiming here first.
            </div>
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            <div className="panel p-3.5 lg:col-span-2">
              <SectionTitle
                title="Hourly Congestion Profile"
                icon={
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
                  </svg>
                }
                right={
                  <div className="flex items-center gap-3 text-[9.5px] font-semibold text-faint uppercase">
                    <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-sm bg-[#22513c]" /> Free</span>
                    <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-sm bg-[#7fbf9a]" /> Steady</span>
                    <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-sm bg-amb" /> Heavy</span>
                    <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-sm bg-red" /> Critical</span>
                  </div>
                }
              />
              <div className="h-[210px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={a.hourly} margin={{ top: 4, right: 4, left: -26, bottom: 0 }}>
                    <XAxis
                      dataKey="h"
                      tick={{ fill: "#626d80", fontSize: 10 }}
                      tickFormatter={(h: number) => `${String(h).padStart(2, "0")}`}
                      axisLine={{ stroke: "#232a34" }}
                      tickLine={false}
                      interval={1}
                    />
                    <YAxis
                      tick={{ fill: "#626d80", fontSize: 10 }}
                      axisLine={false}
                      tickLine={false}
                      allowDecimals={false}
                    />
                    <Tooltip
                      cursor={{ fill: "rgba(242,182,75,0.05)" }}
                      contentStyle={{ background: "#181d24", border: "1px solid #2e3745", borderRadius: 8, fontSize: 11 }}
                      labelStyle={{ color: "#98a2b3" }}
                      labelFormatter={(h) => `Hour ${String(h).padStart(2, "0")}:00 IST`}
                      formatter={(v, _n, item) => [
                        `${v} reads/h · load ${item?.payload?.load}%`,
                        "Traffic",
                      ]}
                    />
                    <Bar dataKey="n" radius={[3, 3, 0, 0]}>
                      {a.hourly.map((b) => (
                        <Cell key={b.h} fill={loadColor(b.load)} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="panel p-3.5">
              <SectionTitle title="Camera Load · 72h" />
              <div className="space-y-3">
                {a.camLoad.map((c) => (
                  <div key={c.code}>
                    <div className="flex items-center justify-between text-[11.5px]">
                      <span>
                        <span className="font-mono font-bold text-sig">{c.code}</span>{" "}
                        <span className="text-mut">{c.name}</span>
                      </span>
                      <span className="font-mono text-[10.5px] text-faint tabular-nums">{c.n} reads</span>
                    </div>
                    <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-line">
                      <div className="h-full rounded-full bg-gradient-to-r from-sigdim to-sig" style={{ width: `${c.share}%` }} />
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 border-t border-line pt-3">
                <div className="mb-2 text-[10px] font-bold tracking-[0.14em] text-faint uppercase">
                  Origin share (registered region)
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {a.regions.map((r) => (
                    <span
                      key={r.region}
                      className="rounded-full border border-line2 bg-raise px-2.5 py-1 font-mono text-[10.5px] font-bold text-mut"
                    >
                      {r.region} <span className="text-faint">{r.share}%</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <div className="panel p-3.5">
              <SectionTitle
                title="Frequently Used Corridors"
                icon={
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="5" cy="19" r="2.5" />
                    <circle cx="19" cy="5" r="2.5" />
                    <path d="M7 17 17 7" />
                  </svg>
                }
                right={<span className="text-[10.5px] text-faint">observed inter-camera moves</span>}
              />
              <div className="space-y-2">
                {a.corridors.map((c, i) => (
                  <div key={`${c.from}${c.to}`} className="rounded-[8px] border border-line bg-raise px-3 py-2.5">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[12px] font-bold text-txt">
                        {c.from} <span className="mx-1 text-sig">→</span> {c.to}
                      </span>
                      <span className="text-[10.5px] text-mut">
                        avg <b className="text-txt">{c.avgMin} min</b> · {c.avgSpeed} km/h
                      </span>
                    </div>
                    <div className="mt-1.5 flex items-center gap-2">
                      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-line">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-sigdim to-sig"
                          style={{ width: `${(c.n / (a.corridors[0]?.n || 1)) * 100}%`, opacity: 1 - i * 0.1 }}
                        />
                      </div>
                      <span className="font-mono text-[10px] text-faint tabular-nums">{c.n} trips</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="panel p-3.5">
              <SectionTitle
                title="Suspicious & Unusual Movements"
                icon={
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M12 3 2.5 20h19L12 3Z" />
                    <path d="M12 10v4M12 17.2v.3" />
                  </svg>
                }
                right={
                  <span className="text-[10.5px] text-faint">
                    rule: speed &gt; 110 km/h inter-camera · wanted list
                  </span>
                }
              />
              <div className="max-h-[430px] space-y-1.5 overflow-y-auto pr-1">
                {a.alerts.length === 0 && (
                  <div className="py-6 text-center text-[11px] text-faint">No flagged movements recorded.</div>
                )}
                {a.alerts.map((al) => (
                  <div
                    key={al.id}
                    className={`flex items-center justify-between gap-2 rounded-[8px] border px-3 py-2 ${
                      al.flag === "wanted" ? "border-red/40 bg-red/[0.07]" : "border-amb/35 bg-amb/[0.05]"
                    }`}
                  >
                    <div className="flex min-w-0 items-center gap-2.5">
                      <PlateChip plate={al.plate} size="sm" />
                      <div className="min-w-0">
                        <div className="truncate text-[11px] font-semibold">
                          <span className="font-mono text-mut">{al.camCode}</span> {al.camName}
                        </div>
                        <div className="text-[9.5px] text-faint">
                          {fmtTime(al.at)} IST · <TimeAgo iso={al.at} /> · conf {Math.round(al.conf * 100)}%
                        </div>
                      </div>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      {al.flag === "speeding" && al.speed != null && (
                        <span className="font-mono text-[12px] font-bold text-red">{Math.round(al.speed)} km/h</span>
                      )}
                      <FlagChip flag={al.flag} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </Shell>
  );
}
