"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/http";
import Shell from "@/components/Shell";
import { PlateChip, LoadingBlock } from "@/components/bits";
import { fmtTime } from "@/lib/geo";

type Cam = {
  id: number;
  code: string;
  name: string;
  area: string;
  direction: string;
  lat: number;
  lng: number;
  online: boolean;
  n24: number;
  avgConf: number;
  lastPlate: string | null;
  lastSeenAt: string | null;
};

function FeedMonitor({ cam, idx }: { cam: Cam; idx: number }) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className={`feedbox aspect-video w-full ${cam.online ? "" : "grayscale opacity-60"}`}>
      <div className="scan" style={{ animationDelay: `${idx * 0.7}s` }} />
      <div className="absolute top-2 left-2.5 flex items-center gap-1.5">
        <span className="rec-dot" />
        <span className="font-mono text-[10px] font-bold tracking-wider text-txt/90">{cam.code} · REC</span>
      </div>
      <div className="absolute top-2 right-2.5 font-mono text-[10px] tracking-wider text-txt/70 tabular-nums">
        {fmtTime(now)} IST
      </div>
      <div className="absolute bottom-2 left-2.5 flex items-center gap-2">
        <span className="rounded-[4px] bg-black/50 px-1.5 py-0.5 font-mono text-[9px] tracking-wider text-sig/90">
          ANPR ACTIVE
        </span>
        <span className="rounded-[4px] bg-black/50 px-1.5 py-0.5 font-mono text-[9px] tracking-wider text-txt/60">
          1080p · H.264
        </span>
      </div>
      <div className="absolute right-2.5 bottom-2 flex items-center gap-1.5">
        {cam.lastPlate ? (
          <span className="rounded-[4px] bg-black/55 px-1.5 py-0.5 font-mono text-[9px] tracking-wider text-amb">
            LAST: {cam.lastPlate}
          </span>
        ) : (
          <span className="rounded-[4px] bg-black/55 px-1.5 py-0.5 font-mono text-[9px] tracking-wider text-txt/50">
            NO PLATES
          </span>
        )}
      </div>
      {/* road silhouette */}
      <svg
        className="pointer-events-none absolute inset-x-0 bottom-0 w-full opacity-25"
        height="34%"
        preserveAspectRatio="none"
        viewBox="0 0 100 34"
      >
        <polygon points="38,34 46,0 54,0 62,34" fill="#20282f" />
        <line x1="50" y1="2" x2="50" y2="34" stroke="#3b4650" strokeWidth="1" strokeDasharray="4 4" />
      </svg>
    </div>
  );
}

export default function CamerasPage() {
  const [cams, setCams] = useState<Cam[] | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    api<{ cameras: Cam[] }>("/api/cameras")
      .then((r) => setCams(r.cameras))
      .catch((e) => setErr(e.message));
  }, []);

  return (
    <Shell>
      <div className="mb-4">
        <h1 className="font-display text-[22px] font-bold tracking-tight">Camera Network</h1>
        <p className="mt-0.5 text-[12.5px] text-mut">
          ANPR edge nodes on the Lucknow pilot grid — plate reads stream from each node to the matching engine
        </p>
      </div>

      {err && (
        <div className="panel border-red/40 p-4 text-sm text-red">
          Failed to load camera network: {err}
        </div>
      )}
      {!cams && !err && (
        <div className="panel">
          <LoadingBlock label="Reading node status" />
        </div>
      )}

      {cams && (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {cams.map((c, i) => (
            <div key={c.id} className="panel p-3.5">
              <div className="mb-2.5 flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[12px] font-bold text-sig">{c.code}</span>
                    <span
                      className={`rounded-full px-1.5 py-px text-[9px] font-bold tracking-widest uppercase ${
                        c.online ? "bg-sig/15 text-sig" : "bg-red/15 text-red"
                      }`}
                    >
                      {c.online ? "Online" : "Offline"}
                    </span>
                  </div>
                  <div className="font-display mt-0.5 text-[15px] font-semibold leading-tight">{c.name}</div>
                  <div className="mt-0.5 text-[11px] text-mut">
                    {c.area} · {c.direction}
                  </div>
                </div>
                <span className="font-mono text-[10px] text-faint tabular-nums">
                  {c.lat.toFixed(4)}, {c.lng.toFixed(4)}
                </span>
              </div>

              <FeedMonitor cam={c} idx={i} />

              <div className="mt-3 grid grid-cols-3 gap-2">
                <div className="rounded-[7px] border border-line bg-raise px-2.5 py-2">
                  <div className="text-[9px] font-bold tracking-[0.12em] text-faint uppercase">Reads · 24h</div>
                  <div className="kpi-num mt-0.5 text-[17px]">{c.n24}</div>
                </div>
                <div className="rounded-[7px] border border-line bg-raise px-2.5 py-2">
                  <div className="text-[9px] font-bold tracking-[0.12em] text-faint uppercase">Avg Conf.</div>
                  <div className="kpi-num mt-0.5 text-[17px] text-sig">
                    {c.avgConf ? `${Math.round(Number(c.avgConf) * 100)}%` : "—"}
                  </div>
                </div>
                <div className="rounded-[7px] border border-line bg-raise px-2.5 py-2">
                  <div className="text-[9px] font-bold tracking-[0.12em] text-faint uppercase">Last Plate</div>
                  <div className="mt-1 flex items-center">
                    {c.lastPlate ? (
                      <PlateChip plate={c.lastPlate} size="sm" />
                    ) : (
                      <span className="text-[10px] text-faint">—</span>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-2 flex items-center justify-between text-[10px] text-faint">
                <span>
                  {c.lastSeenAt ? `Last read ${fmtTime(c.lastSeenAt)} IST` : "No reads yet today"}
                </span>
                <span className="font-mono">GPU · TensorRT · v2.4</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </Shell>
  );
}
