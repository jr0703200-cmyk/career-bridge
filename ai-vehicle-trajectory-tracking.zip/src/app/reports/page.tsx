"use client";

import { Suspense, useCallback, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { api } from "@/lib/http";
import Shell from "@/components/Shell";
import MapView, { type MapPoint } from "@/components/MapView";
import { PlateChip, FlagChip, LoadingBlock, EmptyState, TimeAgo } from "@/components/bits";
import { fmtFull, fmtKm, fmtMinutes, fmtSpeed, VEHICLE_KINDS, normPlate } from "@/lib/geo";

type Veh = {
  plate: string;
  kind: string;
  color: string;
  region: string;
  wanted: boolean;
  first_seen: string;
  last_seen: string;
  n: number;
  cams: number;
  flagged: number;
};

type Point = {
  seq: number;
  at: string;
  camCode: string;
  camName: string;
  camArea: string;
  lat: number | null;
  lng: number | null;
  conf: number;
  prevCamCode: string | null;
  distance: number | null;
  minutes: number | null;
  speed: number | null;
  flag: string | null;
};

type Detail = {
  vehicle: Veh;
  path: Point[];
  summary: {
    sightings: number;
    cameras: number;
    totalDistKm: number;
    durationMin: number;
    avgSpeedKmh: number;
    flagged: number;
  };
};

function reportId(plate: string) {
  let h = 0;
  const s = `${plate}-${new Date().toISOString().slice(0, 10)}`;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return `PT-LW-${h.toString(16).toUpperCase().padStart(8, "0")}`;
}

function ReportsInner() {
  const params = useSearchParams();
  const plateParam = params.get("plate") ?? "";
  const [vehicles, setVehicles] = useState<Veh[] | null>(null);
  const [detail, setDetail] = useState<Detail | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api<{ vehicles: Veh[] }>("/api/vehicles?limit=14").then((r) => setVehicles(r.vehicles)).catch(() => setVehicles([]));
  }, []);

  const load = useCallback(async (plate: string) => {
    setLoading(true);
    setNotFound(false);
    try {
      setDetail(await api<Detail>(`/api/vehicles/${encodeURIComponent(plate)}`));
    } catch {
      setDetail(null);
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (plateParam && normPlate(plateParam)) load(plateParam.trim());
  }, [plateParam, load]);

  const mapPoints: MapPoint[] = (detail?.path ?? [])
    .filter((p) => p.lat != null && p.lng != null)
    .map((p) => ({
      id: p.seq,
      lat: p.lat!,
      lng: p.lng!,
      seq: p.seq,
      label: `${p.camCode} · ${p.camName}`,
      time: p.at,
      flag: p.flag,
      speed: p.speed,
    }));

  const v = detail?.vehicle;

  return (
    <Shell>
      <div className="no-print mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-[22px] font-bold tracking-tight">Evidence Reports</h1>
          <p className="mt-0.5 text-[12.5px] text-mut">
            Movement-history dossiers for investigation handover — printable as PDF
          </p>
        </div>
        {detail && (
          <button
            onClick={() => window.print()}
            className="flex items-center gap-2 rounded-[8px] border border-sig/40 bg-sig/10 px-3.5 py-2 text-[11.5px] font-bold tracking-wide text-sig uppercase transition-colors hover:bg-sig/20"
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M6 9V3h12v6M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" />
              <rect x="6" y="14" width="12" height="7" />
            </svg>
            Print / Save PDF
          </button>
        )}
      </div>

      {!plateParam ? (
        <div className="panel p-3.5">
          {!vehicles ? (
            <LoadingBlock label="Loading vehicle register" />
          ) : vehicles.length === 0 ? (
            <EmptyState title="No vehicles on file" hint="Seed the demo dataset from the sidebar to populate the register." />
          ) : (
            <>
              <div className="mb-3 flex items-center justify-between">
                <h2 className="font-display text-[13px] font-semibold tracking-[0.08em] text-txt uppercase">
                  Vehicle Register
                </h2>
                <span className="text-[10.5px] text-faint">most recently active first</span>
              </div>
              <div className="grid gap-2 md:grid-cols-2 xl:grid-cols-3">
                {vehicles.map((x) => (
                  <div key={x.plate} className="flex items-center justify-between gap-2 rounded-[8px] border border-line bg-raise px-3 py-2.5">
                    <div className="flex min-w-0 items-center gap-2.5">
                      <PlateChip plate={x.plate} size="sm" />
                      <div className="min-w-0">
                        <div className="text-[10.5px] font-semibold text-mut">
                          {VEHICLE_KINDS[x.kind]} · {x.n} reads · {x.cams} cams
                        </div>
                        <div className="text-[9.5px] text-faint">last seen <TimeAgo iso={x.last_seen} /></div>
                      </div>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      {x.wanted && <FlagChip flag="wanted" />}
                      <button
                        onClick={() => window.location.assign(`/reports?plate=${encodeURIComponent(x.plate)}`)}
                        className="rounded-[6px] border border-sig/40 px-2.5 py-1 text-[10px] font-bold tracking-wide text-sig uppercase transition-colors hover:bg-sig/15"
                      >
                        Report
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      ) : (
        <div className="print-paper mx-auto max-w-[900px] rounded-[10px] bg-paper p-8 text-[#1a1d22] shadow-2xl shadow-black/50">
          {loading && <LoadingBlock label="Compiling report" />}
          {!loading && notFound && (
            <EmptyState title={`No ANPR record for ${plateParam}`} hint="Check the registration or pick a vehicle from the register." />
          )}

          {!loading && v && detail && (
            <div className="text-[13px] leading-relaxed">
              {/* header */}
              <div className="flex items-start justify-between border-b-2 border-[#1a1d22] pb-4">
                <div>
                  <div className="flex items-center gap-2 text-[10px] font-bold tracking-[0.22em] text-[#5a6069] uppercase">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <circle cx="12" cy="12" r="8.5" />
                      <path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3" />
                    </svg>
                    PlateTrace · City Vehicle Intelligence
                  </div>
                  <h1 className="font-display mt-1.5 text-[24px] leading-tight font-bold tracking-tight">
                    Vehicle Movement Evidence Report
                  </h1>
                  <div className="mt-1 text-[11.5px] text-[#5a6069]">
                    Lucknow pilot grid · multi-camera ANPR reconstruction
                  </div>
                </div>
                <div className="text-right font-mono text-[11px] leading-relaxed text-[#5a6069]">
                  <div>REPORT {reportId(v.plate)}</div>
                  <div>GENERATED {fmtFull(new Date())} IST</div>
                  <div>CLASS: CONFIDENTIAL</div>
                </div>
              </div>

              {/* wanted banner */}
              {v.wanted && (
                <div className="mt-4 flex items-center gap-2 rounded-[6px] border-2 border-[#c0392b] bg-[#c0392b]/10 px-3 py-2">
                  <svg width="15" height="15" viewBox="0 0 12 12" fill="#c0392b">
                    <path d="M6 0 7.4 4.6 12 6l-4.6 1.4L6 12 4.6 7.4 0 6l4.6-1.4L6 0Z" />
                  </svg>
                  <span className="text-[12px] font-bold tracking-wider text-[#c0392b] uppercase">
                    Alert: vehicle on wanted list — coordinate with traffic police before field action
                  </span>
                </div>
              )}

              {/* subject + parameters */}
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <div className="rounded-[6px] border border-[#d5d1c4] p-3.5">
                  <div className="text-[9.5px] font-bold tracking-[0.18em] text-[#8a8577] uppercase">Subject Vehicle</div>
                  <div className="mt-2">
                    <PlateChip plate={v.plate} size="lg" />
                  </div>
                  <table className="mt-3 w-full text-[11.5px]">
                    <tbody>
                      <tr>
                        <td className="py-0.5 pr-3 text-[#8a8577]">Class</td>
                        <td className="font-semibold">{VEHICLE_KINDS[v.kind]}</td>
                      </tr>
                      <tr>
                        <td className="py-0.5 pr-3 text-[#8a8577]">Colour</td>
                        <td className="font-semibold">{v.color}</td>
                      </tr>
                      <tr>
                        <td className="py-0.5 pr-3 text-[#8a8577]">Registered region</td>
                        <td className="font-semibold">{v.region}</td>
                      </tr>
                      <tr>
                        <td className="py-0.5 pr-3 text-[#8a8577]">First / last on file</td>
                        <td className="font-mono text-[10.5px] font-semibold">
                          {fmtFull(v.first_seen)} → {fmtFull(v.last_seen)}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="rounded-[6px] border border-[#d5d1c4] p-3.5">
                  <div className="text-[9.5px] font-bold tracking-[0.18em] text-[#8a8577] uppercase">Reconstruction Parameters</div>
                  <table className="mt-2 w-full text-[11.5px]">
                    <tbody>
                      <tr>
                        <td className="py-0.5 pr-3 text-[#8a8577]">ANPR nodes</td>
                        <td className="font-semibold">5 (LW-01 … LW-05)</td>
                      </tr>
                      <tr>
                        <td className="py-0.5 pr-3 text-[#8a8577]">Match method</td>
                        <td className="font-semibold">Exact plate, time-ordered</td>
                      </tr>
                      <tr>
                        <td className="py-0.5 pr-3 text-[#8a8577]">Speed rule</td>
                        <td className="font-semibold">&gt; 110 km/h inter-camera ⇒ flagged</td>
                      </tr>
                      <tr>
                        <td className="py-0.5 pr-3 text-[#8a8577]">Time reference</td>
                        <td className="font-mono text-[10.5px] font-semibold">IST (UTC+5:30), NTP-synced cameras</td>
                      </tr>
                    </tbody>
                  </table>
                  <div className="mt-3 grid grid-cols-3 gap-2">
                    {[
                      ["Sightings", String(detail.summary.sightings)],
                      ["Cameras", String(detail.summary.cameras)],
                      ["Flags", String(detail.summary.flagged)],
                    ].map(([l, val]) => (
                      <div key={l} className="rounded-[5px] bg-[#1a1d22]/[0.05] px-2 py-1.5 text-center">
                        <div className="font-display text-[16px] leading-none font-bold">{val}</div>
                        <div className="mt-1 text-[8.5px] font-bold tracking-[0.14em] text-[#8a8577] uppercase">{l}</div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    {[
                      ["Distance", fmtKm(detail.summary.totalDistKm)],
                      ["On road", fmtMinutes(detail.summary.durationMin)],
                      ["Avg speed", fmtSpeed(detail.summary.avgSpeedKmh)],
                    ].map(([l, val]) => (
                      <div key={l} className="rounded-[5px] bg-[#1a1d22]/[0.05] px-2 py-1.5 text-center">
                        <div className="font-display text-[14px] leading-none font-bold">{val}</div>
                        <div className="mt-1 text-[8.5px] font-bold tracking-[0.14em] text-[#8a8577] uppercase">{l}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* map */}
              <div className="mt-5">
                <div className="mb-2 text-[9.5px] font-bold tracking-[0.18em] text-[#8a8577] uppercase">
                  Reconstructed Route
                </div>
                <MapView points={mapPoints} height="300px" showCameras={false} fitKey={v.plate} />
              </div>

              {/* sightings table */}
              <div className="mt-5">
                <div className="mb-2 text-[9.5px] font-bold tracking-[0.18em] text-[#8a8577] uppercase">
                  Movement History — Chronological
                </div>
                <table className="w-full border-collapse text-[11px]">
                  <thead>
                    <tr className="border-b-2 border-[#1a1d22] text-left text-[9px] font-bold tracking-[0.12em] text-[#8a8577] uppercase">
                      <th className="py-1.5 pr-2">#</th>
                      <th className="py-1.5 pr-2">Timestamp (IST)</th>
                      <th className="py-1.5 pr-2">ANPR Node</th>
                      <th className="py-1.5 pr-2">Segment From</th>
                      <th className="py-1.5 pr-2 text-right">Distance</th>
                      <th className="py-1.5 pr-2 text-right">Gap</th>
                      <th className="py-1.5 pr-2 text-right">Est. Speed</th>
                      <th className="py-1.5 pr-2 text-right">Conf.</th>
                      <th className="py-1.5">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {detail.path.map((p) => (
                      <tr key={p.seq} className="border-b border-[#e2ded2]">
                        <td className="py-1.5 pr-2 font-mono font-bold">{String(p.seq).padStart(2, "0")}</td>
                        <td className="py-1.5 pr-2 font-mono text-[10.5px]">{fmtFull(p.at)}</td>
                        <td className="py-1.5 pr-2">
                          <span className="font-mono font-bold">{p.camCode}</span> {p.camName}
                        </td>
                        <td className="py-1.5 pr-2 font-mono text-[10.5px]">{p.prevCamCode ?? "—"}</td>
                        <td className="py-1.5 pr-2 text-right font-mono text-[10.5px]">{fmtKm(p.distance)}</td>
                        <td className="py-1.5 pr-2 text-right font-mono text-[10.5px]">{fmtMinutes(p.minutes)}</td>
                        <td
                          className={`py-1.5 pr-2 text-right font-mono text-[10.5px] font-bold ${
                            p.speed != null && p.speed > 110 ? "text-[#c0392b]" : ""
                          }`}
                        >
                          {fmtSpeed(p.speed)}
                        </td>
                        <td className="py-1.5 pr-2 text-right font-mono text-[10.5px]">{Math.round(p.conf * 100)}%</td>
                        <td className="py-1.5">
                          {p.flag ? (
                            <span
                              className={`rounded-[4px] px-1.5 py-0.5 text-[8.5px] font-bold tracking-wider uppercase ${
                                p.flag === "wanted"
                                  ? "bg-[#c0392b]/10 text-[#c0392b]"
                                  : "bg-[#b07d1e]/10 text-[#8a6212]"
                              }`}
                            >
                              {p.flag}
                            </span>
                          ) : (
                            <span className="text-[9px] font-semibold tracking-wider text-[#4d7c5f] uppercase keep-green">Clear</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* certification */}
              <div className="mt-6 rounded-[6px] border border-[#d5d1c4] p-3.5 text-[10.5px] leading-relaxed text-[#5a6069]">
                This report was auto-generated by the PlateTrace ANPR correlation engine from
                time-stamped plate reads captured on the referenced camera network. Inter-camera distances
                are geodesic (camera GPS), speeds are derived from the time gap between consecutive
                captures and are indicative, not law-enforcement calibrated. Original video evidence
                remains with the respective camera operators.
              </div>
              <div className="mt-8 grid grid-cols-2 gap-8">
                <div className="border-t border-[#1a1d22] pt-1.5 text-[10px] font-semibold tracking-wider text-[#5a6069] uppercase">
                  Generating analyst
                </div>
                <div className="border-t border-[#1a1d22] pt-1.5 text-[10px] font-semibold tracking-wider text-[#5a6069] uppercase">
                  Traffic police reviewer
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between font-mono text-[9.5px] text-[#8a8577]">
                <span>{reportId(v.plate)}</span>
                <span>PlateTrace v0.9 · prototype — not for court evidence</span>
              </div>
            </div>
          )}
        </div>
      )}
    </Shell>
  );
}

export default function ReportsPage() {
  return (
    <Suspense fallback={<Shell><div className="panel"><LoadingBlock /></div></Shell>}>
      <ReportsInner />
    </Suspense>
  );
}
