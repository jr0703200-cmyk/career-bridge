"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "@/lib/http";
import Shell from "@/components/Shell";
import MapView, { type MapCam, type MapPoint } from "@/components/MapView";
import { StatCard, SectionTitle, PlateChip, ConfBar, FlagChip, LoadingBlock, EmptyState, TimeAgo } from "@/components/bits";
import { fmtTime } from "@/lib/geo";
import { BarChart, Bar, XAxis, YAxis, Tooltip, Cell, ResponsiveContainer } from "recharts";

type Det = {
  id: number;
  plate: string;
  camCode: string;
  camName: string;
  at: string;
  conf: number;
  speed: number | null;
  distance: number | null;
  flag: string | null;
};

type Overview = {
  cameras: { total: number; online: number };
  totals: { detections24h: number; trackedVehicles: number; avgConf: number; alerts24h: number };
  hourly: Array<{ h: number; n: number }>;
  recent: Det[];
  alerts: Det[];
};

type Analytics = {
  corridors: Array<{ from: string; to: string; n: number; avgMin: number; avgSpeed: number }>;
};

async function fetchCams(): Promise<MapCam[]> {
  const r = await api<{ cameras: MapCam[] }>("/api/cameras");
  return r.cameras;
}

export default function OverviewPage() {
  const [ov, setOv] = useState<Overview | null>(null);
  const [cams, setCams] = useState<MapCam[]>([]);
  const [corridors, setCorridors] = useState<Analytics["corridors"]>([]);
  const [live, setLive] = useState(true);
  const [fresh, setFresh] = useState<Set<number>>(new Set());
  const liveRef = useRef(true);
  liveRef.current = live;

  const refresh = useCallback(async (gen: boolean) => {
    try {
      let newIds: number[] = [];
      if (gen && liveRef.current) {
        const t = await api<{ detections: Det[] }>("/api/live/tick", { method: "POST" });
        newIds = t.detections.map((d) => d.id);
      }
      const [o, c, a] = await Promise.all([
        api<Overview>("/api/overview"),
        fetchCams(),
        api<Analytics>("/api/analytics"),
      ]);
      setOv(o);
      setCams(c);
      setCorridors(a.corridors);
      setFresh(new Set(newIds));
    } catch {
      /* keep last good state */
    }
  }, []);

  useEffect(() => {
    refresh(false).then(() =>
      refresh(true).catch(() => undefined),
    );
    const t = setInterval(() => refresh(true), 5000);
    return () => clearInterval(t);
  }, [refresh]);

  const mapPoints: MapPoint[] = (ov?.recent ?? [])
    .slice()
    .reverse()
    .filter((d) => {
      const cam = cams.find((c) => c.code === d.camCode);
      return cam;
    })
    .map((d, i) => {
      const cam = cams.find((c) => c.code === d.camCode)!;
      return {
        id: d.id,
        lat: cam.lat,
        lng: cam.lng,
        seq: i + 1,
        label: d.camCode,
        time: d.at,
        flag: d.flag,
        speed: d.speed,
      };
    });

  const peakH = ov
    ? ov.hourly.reduce((a, b) => (b.n > a.n ? b : a), ov.hourly[0])?.h
    : -1;

  return (
    <Shell>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-[22px] font-bold tracking-tight">City Operations Overview</h1>
          <p className="mt-0.5 text-[12.5px] text-mut">
            Cross-camera ANPR activity across the Lucknow pilot grid — last 24 hours
          </p>
        </div>
        <button
          onClick={() => setLive((v) => !v)}
          className={`flex items-center gap-2 rounded-[8px] border px-3 py-1.5 text-[11px] font-bold tracking-[0.12em] uppercase transition-colors ${
            live ? "border-sig/40 bg-sig/10 text-sig" : "border-line2 text-mut hover:text-txt"
          }`}
        >
          <span className={live ? "dot-live" : "h-2 w-2 rounded-full bg-faint"} />
          {live ? "Live feed on" : "Live feed paused"}
        </button>
      </div>

      {!ov ? (
        <div className="panel">
          <LoadingBlock label="Connecting to ANPR grid" />
        </div>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
            <StatCard
              label="Active Cameras"
              value={`${ov.cameras.online}/${ov.cameras.total}`}
              sub="ANPR nodes online"
            />
            <StatCard
              label="Detections · 24h"
              value={ov.totals.detections24h.toLocaleString("en-IN")}
              sub="Plate reads captured"
            />
            <StatCard
              label="Tracked Vehicles"
              value={ov.totals.trackedVehicles.toLocaleString("en-IN")}
              sub="Unique plates on file"
            />
            <StatCard
              label="Avg ANPR Conf."
              value={`${Math.round(ov.totals.avgConf * 100)}%`}
              tone="sig"
              sub="OCR accuracy"
            />
            <StatCard
              label="Alerts · 24h"
              value={ov.totals.alerts24h}
              tone={ov.totals.alerts24h > 0 ? "red" : "default"}
              sub="Wanted / speeding"
            />
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            <div className="panel p-3.5 lg:col-span-2">
              <SectionTitle
                title="City Activity Map"
                icon={
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M12 21s-7-5.5-7-11a7 7 0 1 1 14 0c0 5.5-7 11-7 11Z" />
                    <circle cx="12" cy="10" r="2.5" />
                  </svg>
                }
                right={
                  <span className="text-[10.5px] text-faint">
                    latest {mapPoints.length} plate reads
                  </span>
                }
              />
              <MapView cams={cams} points={mapPoints} height="430px" fitKey="overview" />
            </div>

            <div className="flex flex-col gap-4">
              <div className="panel flex-1 p-3.5">
                <SectionTitle
                  title="Live Detection Feed"
                  icon={
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M4 12h4l3-8 4 16 3-8h2" />
                    </svg>
                  }
                  right={
                    <span className="flex items-center gap-1.5 text-[10px] font-bold tracking-widest text-sig uppercase">
                      <span className={live ? "dot-live" : "h-2 w-2 rounded-full bg-faint"} />
                      {live ? "streaming" : "paused"}
                    </span>
                  }
                />
                <div className="max-h-[300px] space-y-1 overflow-y-auto pr-1">
                  {ov.recent.length === 0 && (
                    <EmptyState title="No detections yet" hint="Enable the live feed to start ingesting plate reads." />
                  )}
                  {ov.recent.map((d) => (
                    <div
                      key={d.id}
                      className={`flex items-center justify-between gap-2 rounded-[7px] border border-transparent px-2 py-1.5 ${
                        fresh.has(d.id) ? "flash-in" : ""
                      }`}
                    >
                      <div className="flex min-w-0 items-center gap-2">
                        <PlateChip plate={d.plate} size="sm" />
                        <div className="min-w-0">
                          <div className="truncate font-mono text-[10px] text-mut">
                            {d.camCode} · {d.camName}
                          </div>
                          <div className="text-[9.5px] text-faint">
                            {fresh.has(d.id) ? "just now" : <TimeAgo iso={d.at} />}
                          </div>
                        </div>
                      </div>
                      <div className="flex shrink-0 flex-col items-end gap-1">
                        <ConfBar value={d.conf} />
                        {d.flag ? (
                          <FlagChip flag={d.flag} />
                        ) : (
                          <span className="text-[9.5px] text-faint">{fmtTime(d.at)} IST</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="panel p-3.5">
                <SectionTitle
                  title="Active Alerts"
                  icon={
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M12 3 2.5 20h19L12 3Z" />
                      <path d="M12 10v4M12 17.2v.3" />
                    </svg>
                  }
                />
                {ov.alerts.length === 0 ? (
                  <div className="py-4 text-center text-[11px] text-faint">No alerts in the last 24h.</div>
                ) : (
                  <div className="space-y-1.5">
                    {ov.alerts.map((a) => (
                      <div
                        key={a.id}
                        className="flex items-center justify-between rounded-[7px] border border-red/25 bg-red/5 px-2 py-1.5"
                      >
                        <div className="flex items-center gap-2">
                          <PlateChip plate={a.plate} size="sm" />
                          <span className="font-mono text-[10px] text-mut">{a.camCode}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {a.speed != null && (
                            <span className="text-[10px] font-bold text-red">{Math.round(a.speed)} km/h</span>
                          )}
                          <FlagChip flag={a.flag} />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            <div className="panel p-3.5 lg:col-span-2">
              <SectionTitle
                title="Plate Read Volume by Hour (IST · 24h)"
                icon={
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
                  </svg>
                }
              />
              <div className="h-[190px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={ov.hourly} margin={{ top: 4, right: 4, left: -26, bottom: 0 }}>
                    <XAxis
                      dataKey="h"
                      tick={{ fill: "#626d80", fontSize: 10 }}
                      tickFormatter={(h: number) => `${String(h).padStart(2, "0")}`}
                      axisLine={{ stroke: "#232a34" }}
                      tickLine={false}
                      interval={1}
                    />
                    <YAxis
                      tick={{ fill: "#626d80", fontSize: 10 }}
                      axisLine={false}
                      tickLine={false}
                      allowDecimals={false}
                    />
                    <Tooltip
                      cursor={{ fill: "rgba(61,220,151,0.06)" }}
                      contentStyle={{ background: "#181d24", border: "1px solid #2e3745", borderRadius: 8, fontSize: 11 }}
                      labelStyle={{ color: "#98a2b3" }}
                      labelFormatter={(h) => `Hour ${String(h).padStart(2, "0")}:00 IST`}
                      formatter={(v) => [`${v} reads`, "Volume"]}
                    />
                    <Bar dataKey="n" radius={[3, 3, 0, 0]}>
                      {ov.hourly.map((b) => (
                        <Cell key={b.h} fill={b.h === peakH ? "#3ddc97" : "#22513c"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="panel p-3.5">
              <SectionTitle
                title="Busiest Corridors"
                icon={
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="5" cy="19" r="2.5" />
                    <circle cx="19" cy="5" r="2.5" />
                    <path d="M7 17 17 7" />
                  </svg>
                }
                right={<span className="text-[10.5px] text-faint">72h window</span>}
              />
              <div className="space-y-2.5">
                {corridors.slice(0, 5).map((c, i) => (
                  <div key={`${c.from}-${c.to}`}>
                    <div className="flex items-center justify-between text-[11.5px]">
                      <span className="font-mono font-semibold text-mut">
                        {c.from} <span className="text-faint">→</span> {c.to}
                      </span>
                      <span className="text-[10.5px] text-faint">
                        {c.n} trips · avg <span className="text-txt">{c.avgMin} min</span>
                      </span>
                    </div>
                    <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-line">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-sigdim to-sig"
                        style={{ width: `${(c.n / (corridors[0]?.n || 1)) * 100}%`, opacity: 1 - i * 0.12 }}
                      />
                    </div>
                  </div>
                ))}
                {corridors.length === 0 && (
                  <div className="py-4 text-center text-[11px] text-faint">Not enough cross-camera matches yet.</div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </Shell>
  );
}
