import { db } from "@/db";
import { cameras, detections } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const d24 = new Date(Date.now() - 24 * 3600 * 1000);
  const lastPlate = (
    await db.execute(
      sql<{ camera_id: number; plate: string; at: Date }>`
        select camera_id, plate, detected_at as at
        from (
          select camera_id, plate, detected_at,
                 row_number() over (partition by camera_id order by detected_at desc) rn
          from detections
        ) t where rn = 1
      `,
    )
  ).rows;
  const [cams, stats] = await Promise.all([
    db.select().from(cameras).orderBy(sql`${cameras.id}`),
    db
      .select({
        camera_id: detections.camera_id,
        n: sql<number>`count(*)`,
        avgConf: sql<number>`round(avg(${detections.confidence})::numeric, 2)`,
      })
      .from(detections)
      .where(sql`${detections.detected_at} >= ${d24}`)
      .groupBy(detections.camera_id),
  ]);

  return Response.json({
    cameras: cams.map((c) => {
      const lp = lastPlate.find((s) => s.camera_id === c.id);
      const at = lp ? (lp.at as unknown as Date | string) : null;
      return {
        ...c,
        n24: stats.find((s) => s.camera_id === c.id)?.n ?? 0,
        avgConf: stats.find((s) => s.camera_id === c.id)?.avgConf ?? 0,
        lastPlate: lp?.plate ?? null,
        lastSeenAt: at ? new Date(at).toISOString() : null,
      };
    }),
  });
}
