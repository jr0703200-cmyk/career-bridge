import { db } from "@/db";
import { cameras, vehicles, detections } from "@/db/schema";
import { runSeed } from "@/db/seed";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const url = new URL(req.url);
  const clear = url.searchParams.get("clear") === "1";
  await runSeed(clear);
  const [c, v, d] = await Promise.all([
    db.select({ n: sql<number>`count(*)` }).from(cameras),
    db.select({ n: sql<number>`count(*)` }).from(vehicles),
    db.select({ n: sql<number>`count(*)` }).from(detections),
  ]);
  return Response.json({
    ok: true,
    cleared: clear,
    cameras: c[0].n,
    vehicles: v[0].n,
    detections: d[0].n,
  });
}
