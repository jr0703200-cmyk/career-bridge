import { db } from "@/db";
import { vehicles, detections, cameras } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { normPlate } from "@/lib/geo";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ plate: string }> }) {
  await ensureSeeded();
  const { plate: raw } = await ctx.params;
  const plate = normPlate(raw).replace(/(\d{2})([A-Z]{1,2})(\d{3,4})$/, "$1 $2 $3");
  // fallback: keep original casing/spacing as stored
  const vRow = await db
    .select()
    .from(vehicles)
    .where(eq(vehicles.plate, plate))
    .limit(1);
  const vehicle = vRow[0];
  if (!vehicle) {
    return Response.json({ error: "Vehicle not found" }, { status: 404 });
  }

  const cams = await db.select().from(cameras);
  const camById = new Map(cams.map((c) => [c.id, c]));
  const dets = await db
    .select()
    .from(detections)
    .where(eq(detections.plate, vehicle.plate))
    .orderBy(sql`${detections.detected_at} ASC`);

  let totalDist = 0;
  const path = dets.map((d, i) => {
    const cam = camById.get(d.camera_id);
    const prevCam = d.prev_camera_id ? camById.get(d.prev_camera_id) : undefined;
    if (d.distance_km != null) totalDist += d.distance_km;
    return {
      seq: i + 1,
      at: d.detected_at.toISOString(),
      cameraId: d.camera_id,
      camCode: cam?.code ?? "",
      camName: cam?.name ?? "",
      camArea: cam?.area ?? "",
      lat: cam?.lat ?? null,
      lng: cam?.lng ?? null,
      conf: d.confidence,
      prevCamCode: prevCam?.code ?? null,
      distance: d.distance_km,
      minutes: d.minutes,
      speed: d.speed_kmh,
      flag: d.flag,
    };
  });

  const duration =
    dets.length >= 2
      ? (dets[dets.length - 1].detected_at.getTime() - dets[0].detected_at.getTime()) / 60000
      : 0;
  return Response.json({
    vehicle: {
      plate: vehicle.plate,
      kind: vehicle.kind,
      color: vehicle.color,
      region: vehicle.region,
      wanted: vehicle.wanted,
      first_seen: vehicle.first_seen.toISOString(),
      last_seen: vehicle.last_seen.toISOString(),
    },
    path,
    summary: {
      sightings: dets.length,
      cameras: new Set(path.map((p) => p.camCode)).size,
      totalDistKm: Math.round(totalDist * 10) / 10,
      durationMin: Math.round(duration),
      avgSpeedKmh: duration > 0 ? Math.round(totalDist / (duration / 60)) : 0,
      flagged: dets.filter((d) => d.flag != null).length,
    },
  });
}
