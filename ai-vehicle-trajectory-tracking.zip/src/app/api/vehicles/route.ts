import { db } from "@/db";
import { vehicles, detections } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { normPlate } from "@/lib/geo";
import { ilike, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeeded();
  const url = new URL(req.url);
  const q = normPlate(url.searchParams.get("q") ?? "");
  const limit = Math.min(parseInt(url.searchParams.get("limit") ?? "20", 10) || 20, 50);

  const where = q ? ilike(vehicles.plate, `%${q}%`) : undefined;
  const rows = await db
    .select()
    .from(vehicles)
    .where(where)
    .orderBy(sql`${vehicles.last_seen} DESC`)
    .limit(limit);

  const stats = await db
    .select({
      plate: detections.plate,
      n: sql<number>`count(*)`,
      cams: sql<number>`count(distinct ${detections.camera_id})`,
      flagged: sql<number>`count(${sql`${detections.flag}`})`,
    })
    .from(detections)
    .groupBy(detections.plate);
  const byPlate = new Map(stats.map((s) => [s.plate, s]));

  return Response.json({
    vehicles: rows.map((v) => ({
      plate: v.plate,
      kind: v.kind,
      color: v.color,
      region: v.region,
      wanted: v.wanted,
      first_seen: v.first_seen.toISOString(),
      last_seen: v.last_seen.toISOString(),
      n: byPlate.get(v.plate)?.n ?? 0,
      cams: byPlate.get(v.plate)?.cams ?? 0,
      flagged: byPlate.get(v.plate)?.flagged ?? 0,
    })),
  });
}
