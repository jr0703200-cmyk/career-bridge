import { db } from "@/db";
import { cameras, vehicles, detections } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

const IST = new Intl.DateTimeFormat("en-GB", {
  timeZone: "Asia/Kolkata",
  hour: "2-digit",
  hour12: false,
});

export async function GET() {
  await ensureSeeded();
  const now = Date.now();
  const d24 = new Date(now - 24 * 3600 * 1000);

  const [camRows, vehCount, det24, alerts, recent] = await Promise.all([
    db.select().from(cameras),
    db.select({ n: sql<number>`count(*)` }).from(vehicles),
    db.select().from(detections).where(sql`${detections.detected_at} >= ${d24}`),
    db
      .select()
      .from(detections)
      .where(sql`${detections.detected_at} >= ${d24} and ${detections.flag} is not null`)
      .orderBy(sql`${detections.detected_at} DESC`)
      .limit(6),
    db
      .select()
      .from(detections)
      .orderBy(sql`${detections.detected_at} DESC`)
      .limit(24),
  ]);

  const camById = new Map(camRows.map((c) => [c.id, c]));
  const attach = (d: (typeof recent)[number]) => {
    const cam = camById.get(d.camera_id);
    return {
      id: d.id,
      plate: d.plate,
      camCode: cam?.code ?? "",
      camName: cam?.name ?? "",
      at: d.detected_at.toISOString(),
      conf: d.confidence,
      speed: d.speed_kmh,
      distance: d.distance_km,
      flag: d.flag,
    };
  };

  // hourly buckets (IST hour) for the last 24h
  const hourly = Array.from({ length: 24 }, (_, i) => ({ h: i, n: 0 }));
  let confSum = 0;
  for (const d of det24) {
    const h = parseInt(IST.format(d.detected_at), 10) % 24;
    hourly[h].n += 1;
    confSum += d.confidence;
  }

  const alertRows = alerts.filter((a) => a.flag != null);
  return Response.json({
    cameras: { total: camRows.length, online: camRows.filter((c) => c.online).length },
    totals: {
      detections24h: det24.length,
      trackedVehicles: vehCount[0]?.n ?? 0,
      avgConf: det24.length ? Math.round((confSum / det24.length) * 100) / 100 : 0,
      alerts24h: alertRows.length,
    },
    hourly,
    recent: recent.map(attach),
    alerts: alertRows.map(attach),
  });
}
