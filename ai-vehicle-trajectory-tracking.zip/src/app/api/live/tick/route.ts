import { db } from "@/db";
import { cameras } from "@/db/schema";
import { ensureSeeded, liveTick } from "@/db/seed";

export const dynamic = "force-dynamic";

export async function POST() {
  await ensureSeeded();
  const rows = await liveTick();
  const cams = await db.select().from(cameras);
  const camById = new Map(cams.map((c) => [c.id, c]));
  return Response.json({
    ok: true,
    at: new Date().toISOString(),
    detections: rows.map((r) => {
      const d = r as Record<string, unknown>;
      const cam = camById.get(Number(d.camera_id));
      return {
        id: d.id,
        plate: d.plate,
        camCode: cam?.code ?? "",
        camName: cam?.name ?? "",
        at: new Date(Number(d.detected_at)).toISOString(),
        conf: d.confidence,
        speed: d.speed_kmh ?? null,
        distance: d.distance_km ?? null,
        flag: d.flag ?? null,
        live: true,
      };
    }),
  });
}
