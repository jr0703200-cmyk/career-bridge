import { db } from "@/db";
import { cameras, detections, vehicles } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

const istHour = new Intl.DateTimeFormat("en-GB", {
  timeZone: "Asia/Kolkata",
  hour: "2-digit",
  hour12: false,
});

export async function GET() {
  await ensureSeeded();
  const d72 = new Date(Date.now() - 72 * 3600 * 1000);
  const cams = await db.select().from(cameras);
  const camById = new Map(cams.map((c) => [c.id, c]));

  const [all, alerts, regionRows] = await Promise.all([
    db.select().from(detections).where(sql`${detections.detected_at} >= ${d72}`),
    db
      .select()
      .from(detections)
      .where(sql`${detections.flag} is not null`)
      .orderBy(sql`${detections.detected_at} DESC`)
      .limit(14),
    db
      .select({
        region: vehicles.region,
        n: sql<number>`count(*)`,
      })
      .from(vehicles)
      .groupBy(vehicles.region)
      .orderBy(sql`count(*) DESC`)
      .limit(7),
  ]);

  // 24h buckets averaged over 3 days (congestion profile)
  const hourly: Array<{ h: number; n: number; load: number }> = Array.from(
    { length: 24 },
    (_, i) => ({ h: i, n: 0, load: 0 }),
  );
  for (const d of all) {
    const h = parseInt(istHour.format(d.detected_at), 10) % 24;
    hourly[h].n += 1;
  }
  for (const b of hourly) b.n = Math.round((b.n / 3) * 10) / 10;
  const maxH = Math.max(...hourly.map((b) => b.n), 1);
  for (const b of hourly) b.load = Math.round((b.n / maxH) * 100);

  // corridors: ordered camera pairs
  const pairMap = new Map<
    string,
    { from: string; to: string; n: number; mins: number; speed: number }
  >();
  for (const d of all) {
    if (d.prev_camera_id == null || d.prev_camera_id === d.camera_id) continue;
    const from = camById.get(d.prev_camera_id);
    const to = camById.get(d.camera_id);
    if (!from || !to) continue;
    const key = `${from.id}-${to.id}`;
    const cur = pairMap.get(key) ?? { from: from.code, to: to.code, n: 0, mins: 0, speed: 0 };
    cur.n += 1;
    cur.mins += d.minutes ?? 0;
    cur.speed += d.speed_kmh ?? 0;
    pairMap.set(key, cur);
  }
  const corridors = [...pairMap.values()]
    .map((c) => ({
      from: c.from,
      to: c.to,
      n: c.n,
      avgMin: Math.round((c.mins / c.n) * 10) / 10,
      avgSpeed: Math.round(c.speed / c.n),
    }))
    .sort((a, b) => b.n - a.n)
    .slice(0, 8);

  // camera load
  const camLoad = cams
    .map((c) => {
      const n = all.filter((d) => d.camera_id === c.id).length;
      return { code: c.code, name: c.name, n, share: 0 };
    })
    .sort((a, b) => b.n - a.n);
  const maxCam = Math.max(...camLoad.map((c) => c.n), 1);
  for (const c of camLoad) c.share = Math.round((c.n / maxCam) * 100);

  const peak = hourly.reduce((a, b) => (b.n > a.n ? b : a), hourly[0]);
  const total = all.length;

  return Response.json({
    windowHours: 72,
    total,
    hourly,
    peak: { hour: peak.h, label: `${String(peak.h).padStart(2, "0")}:00`, load: peak.load, n: peak.n },
    corridors,
    regions: regionRows.map((r) => ({
      region: r.region,
      n: r.n,
      share: Math.round((r.n / Math.max(regionRows.reduce((a, b) => a + b.n, 0), 1)) * 100),
    })),
    camLoad,
    alerts: alerts.map((a) => {
      const cam = camById.get(a.camera_id);
      return {
        id: a.id,
        plate: a.plate,
        at: a.detected_at.toISOString(),
        camCode: cam?.code ?? "",
        camName: cam?.name ?? "",
        speed: a.speed_kmh,
        flag: a.flag,
        conf: a.confidence,
      };
    }),
  });
}
