export function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

const IST = {
  dt: new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }),
  full: new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    weekday: "short",
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }),
  time: new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }),
  day: new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    day: "2-digit",
    month: "short",
  }),
};

export const fmtTime = (iso: string | Date) => IST.dt.format(iso instanceof Date ? iso : new Date(iso));
export const fmtFull = (iso: string | Date) => IST.full.format(iso instanceof Date ? iso : new Date(iso));
export const fmtClock = (d: Date) => IST.time.format(d);
export const fmtDay = (d: Date) => IST.day.format(d);

export function fmtMinutes(m: number | null | undefined): string {
  if (m == null || !isFinite(m)) return "—";
  if (m < 1) return `${Math.round(m * 60)}s`;
  if (m < 60) return `${m.toFixed(1)} min`;
  const h = Math.floor(m / 60);
  return `${h}h ${Math.round(m % 60)}m`;
}

export function fmtKm(km: number | null | undefined): string {
  if (km == null || !isFinite(km)) return "—";
  return `${km.toFixed(km < 1 ? 2 : 1)} km`;
}

export function fmtSpeed(k: number | null | undefined): string {
  if (k == null || !isFinite(k)) return "—";
  return `${Math.round(k)} km/h`;
}

/** Normalize a plate for matching: uppercase, strip spaces, dashes. */
export const normPlate = (p: string) => p.toUpperCase().replace(/[\s-]/g, "");

/** Indian plates like UP16 AB 1234 — group into classic plate layout. */
export function plateGroups(plate: string): string[] {
  const p = normPlate(plate);
  // e.g. UP16AB1234 -> UP16 | AB | 1234
  const m = p.match(/^([A-Z]{1,2}\d{1,3}[A-Z]?)([A-Z]{0,2})(\d{1,5})$/);
  if (m) {
    const parts = [m[1]];
    if (m[2]) parts.push(m[2]);
    parts.push(m[3]);
    return parts;
  }
  return [p];
}

export const VEHICLE_KINDS: Record<string, string> = {
  car: "Car",
  two_wheeler: "Two-wheeler",
  bus: "Bus / Commercial",
  truck: "Truck",
};
